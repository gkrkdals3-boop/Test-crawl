﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

resp = requests.get("https://www.boannews.com/", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")

# 날짜 패턴이 있는 요소들 확인
date_pattern = re.compile(r"\d{4}[./\-]\d{2}[./\-]\d{2}|\d+시간\s*전|\d+분\s*전|\d{2}\.\d{2}")
for tag in soup.find_all(True):
    text = tag.get_text(strip=True)
    if date_pattern.search(text) and tag.name in ("span", "p", "div", "td", "li", "em", "small"):
        children = list(tag.children)
        if len(children) <= 3:
            print(f"<{tag.name} class='{tag.get('class')}'>: {text[:100]}")

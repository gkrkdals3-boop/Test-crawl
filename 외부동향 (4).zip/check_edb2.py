﻿import sys, io, requests, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
from datetime import datetime, timedelta
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "X-Requested-With": "XMLHttpRequest",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Referer": "https://www.exploit-db.com/",
}
params = {
    "draw":"1",
    "columns[0][data]":"date_published","columns[0][name]":"date_published",
    "columns[1][data]":"download","columns[2][data]":"application_md5",
    "columns[3][data]":"verified","columns[4][data]":"is_webapps",
    "columns[5][data]":"type","columns[6][data]":"platform",
    "columns[7][data]":"author","columns[8][data]":"description",
    "order[0][column]":"0","order[0][dir]":"desc",
    "start":"0","length":"10",
    "search[value]":"","search[regex]":"false",
}
resp = requests.get("https://www.exploit-db.com/search", headers=headers, params=params, timeout=20)
data = resp.json()
print(f"recordsTotal: {data.get('recordsTotal')}  recordsFiltered: {data.get('recordsFiltered')}")
for exp in data.get("data", []):
    print(f"  id={exp.get('id')}  date={exp.get('date_published')}  desc={str(exp.get('description',''))[:60]}")

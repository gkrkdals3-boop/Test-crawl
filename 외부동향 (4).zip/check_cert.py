﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
resp = requests.get("https://www.kb.cert.org/vuls/", headers=headers, timeout=15)
soup = BeautifulSoup(resp.text, "html.parser")
print(f"Status: {resp.status_code} / HTML 길이: {len(resp.text)}")

# 링크와 날짜 샘플
rows = soup.select("table tbody tr") or soup.select("tr")
print(f"tr 태그: {len(rows)}")
for r in rows[:5]:
    print(f"  {r.get_text(strip=True)[:120]}")

# 날짜 패턴 검색
import re
for tag in soup.find_all(True):
    t = tag.get_text(strip=True)
    if re.search(r"202[0-9]", t) and len(t) < 30:
        print(f"  날짜후보 <{tag.name}>: {t}")
        break

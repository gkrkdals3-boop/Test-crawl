﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
resp = requests.get("https://www.boannews.com/", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")

# [날짜] 형식 링크 모두 수집
date_pattern = re.compile(r"\[(\d{4})\.(\d{2})\.(\d{2})\]")
results = []
for a in soup.find_all("a", href=True):
    text = a.get_text(strip=True)
    m = date_pattern.search(text)
    if m:
        title = date_pattern.sub("", text).strip()
        date_str = f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
        href = a["href"]
        if not href.startswith("http"):
            href = "https://www.boannews.com" + href
        results.append((date_str, title, href))

print(f"총 {len(results)}건 발견")
for d, t, u in results[:10]:
    print(f"  {d} | {t[:50]} | {u[:70]}")

# 뉴스 목록 페이지 URL 찾기
for a in soup.find_all("a", href=True):
    href = a["href"]
    if "list" in href.lower() or "t_list" in href.lower():
        print("목록 링크:", href, "|", a.get_text(strip=True)[:30])

﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
resp = requests.get("https://www.boannews.com/", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")

date_pattern = re.compile(r"\[(\d{4}\.\d{2}\.\d{2})\]")
for tag in soup.find_all(True):
    text = tag.get_text(strip=True)
    if date_pattern.search(text) and tag.name in ("span","p","div","td","li","em","small"):
        children = list(tag.children)
        if len(children) <= 3:
            # 부모 구조 확인
            parent = tag.parent
            print("=== 요소 ===")
            print(f"  현재: <{tag.name}> {text[:80]}")
            print(f"  부모: <{parent.name} class='{parent.get('class')}'>")
            gp = parent.parent
            print(f"  조부: <{gp.name} class='{gp.get('class')}'>")
            # 같은 부모 안에 a 태그가 있는지
            a_in_parent = parent.find("a", href=True)
            if a_in_parent:
                print(f"  링크: {a_in_parent.get('href')} | {a_in_parent.get_text(strip=True)[:60]}")
            break

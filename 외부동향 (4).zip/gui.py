#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
보안 외부 동향 작성 GUI 툴
"""
import sys, io, os, threading
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from main import (
    crawl_boannews, fetch_boannews_article,
    crawl_kisa, crawl_certcc, parse_cve_data,
    crawl_exploitdb, run_git_py, create_docx, create_email_text, get_dates
)

# ══════════════════════════════════════════════════════════════
# 색상 / 공통 상수
# ══════════════════════════════════════════════════════════════
CLR_HEADER = '#1a3a5c'
CLR_ACCENT = '#2e6da4'
CLR_OK     = '#1a7a1a'
CLR_WARN   = '#c07000'
CLR_ERR    = '#cc0000'
CLR_LIGHT  = '#f4f6f9'
FONT_MAIN  = ('맑은 고딕', 9)
FONT_BOLD  = ('맑은 고딕', 9, 'bold')
FONT_MONO  = ('Consolas', 9)
FONT_TITLE = ('맑은 고딕', 14, 'bold')


# ══════════════════════════════════════════════════════════════
# 커스텀 위젯: 체크박스 드롭다운
# ══════════════════════════════════════════════════════════════
class CheckboxDropdown(tk.Frame):
    """
    버튼 클릭 → 팝업 체크박스 목록 표시
    확인 버튼 클릭 → on_change(selected_data_list) 콜백
    """

    def __init__(self, parent, on_change=None, width=28, **kwargs):
        super().__init__(parent, **kwargs)
        self.on_change = on_change
        self._width    = width
        self.items     = []   # [{'label': str, 'data': any}, ...]
        self.checked   = []   # [bool, ...]
        self._popup    = None

        self._btn_text = tk.StringVar(value="▼  뉴스 선택  (0 / 0)")
        self._btn = ttk.Button(self, textvariable=self._btn_text,
                               command=self._toggle_popup, width=self._width)
        self._btn.pack(fill='x')

    # ── 공개 API ──────────────────────────────────────────────

    def set_items(self, items):
        """items: list of {'label': str, 'data': any}"""
        self.items   = items
        self.checked = [False] * len(items)
        self._refresh_label()
        self._btn.config(state='normal')

    def get_selected(self):
        return [self.items[i]['data'] for i, v in enumerate(self.checked) if v]

    def uncheck(self, data_obj):
        for i, item in enumerate(self.items):
            if item['data'] is data_obj:
                self.checked[i] = False
                break
        self._refresh_label()

    # ── 내부 ──────────────────────────────────────────────────

    def _refresh_label(self):
        n = sum(self.checked)
        self._btn_text.set(f"▼  뉴스 선택  ({n} / {len(self.items)})")

    def _toggle_popup(self):
        if self._popup and self._popup.winfo_exists():
            self._close_popup()
            return
        self._open_popup()

    def _open_popup(self):
        bx = self._btn.winfo_rootx()
        by = self._btn.winfo_rooty() + self._btn.winfo_height() + 2
        bw = self._btn.winfo_width()

        popup = tk.Toplevel(self)
        popup.wm_overrideredirect(True)
        popup.geometry(f"+{bx}+{by}")
        self._popup = popup

        outer = tk.Frame(popup, bd=1, relief='solid', bg='#ccc')
        outer.pack(fill='both', expand=True)

        btn_row = tk.Frame(outer, bg='#eef2f7', pady=4)
        btn_row.pack(fill='x')
        ttk.Button(btn_row, text="전체 선택", width=9,
                   command=lambda: self._select_all(True)).pack(side='left', padx=4)
        ttk.Button(btn_row, text="전체 해제", width=9,
                   command=lambda: self._select_all(False)).pack(side='left', padx=2)
        ttk.Button(btn_row, text="확인 ✓", width=8,
                   command=self._confirm_popup).pack(side='right', padx=4)

        ttk.Separator(outer).pack(fill='x')

        pop_w = max(bw, 460)
        pop_h = min(280, len(self.items) * 22 + 10)

        canvas = tk.Canvas(outer, width=pop_w, height=pop_h,
                           highlightthickness=0, bg='white')
        sb = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        inner = tk.Frame(canvas, bg='white')
        win_id = canvas.create_window((0, 0), window=inner, anchor='nw')

        self._cb_vars = []
        for i, item in enumerate(self.items):
            var = tk.BooleanVar(value=self.checked[i])
            self._cb_vars.append(var)
            cb = tk.Checkbutton(
                inner, text=item['label'], variable=var,
                anchor='w', justify='left', wraplength=pop_w - 30,
                bg='white', activebackground='#ddeeff',
                font=FONT_MAIN, pady=1
            )
            cb.pack(fill='x', padx=6)

        def _on_inner(e):
            canvas.configure(scrollregion=canvas.bbox('all'))
            canvas.itemconfig(win_id, width=pop_w)

        inner.bind('<Configure>', _on_inner)
        canvas.bind('<MouseWheel>',
                    lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), 'units'))
        popup.bind('<Escape>', lambda e: self._close_popup())
        popup.focus_set()

    def _select_all(self, state):
        for v in self._cb_vars:
            v.set(state)

    def _confirm_popup(self):
        if self._cb_vars:
            self.checked = [v.get() for v in self._cb_vars]
        self._refresh_label()
        self._close_popup()
        if self.on_change:
            self.on_change(self.get_selected())

    def _close_popup(self):
        if self._popup and self._popup.winfo_exists():
            self._popup.destroy()
        self._popup = None


# ══════════════════════════════════════════════════════════════
# 메인 앱
# ══════════════════════════════════════════════════════════════
class SecurityTrendApp:

    def __init__(self, root):
        self.root = root
        self.root.title("보안 외부 동향 작성 툴")
        self.root.geometry("980x740")
        self.root.minsize(800, 600)
        self.root.configure(bg=CLR_LIGHT)

        self.boannews_selected = []
        self.kisa_data         = []
        self.certcc_data       = []
        self.cve_data          = []
        self.exploitdb_data    = []
        self.github_pocs       = []

        self._build_ui()

    # ══════════════════════════════════════════════════════════
    # UI 빌드
    # ══════════════════════════════════════════════════════════

    def _build_ui(self):
        self._apply_style()
        self._build_header()
        self._build_scrollable_body()
        self._build_footer()

    def _apply_style(self):
        s = ttk.Style()
        try:
            s.theme_use('vista')
        except Exception:
            pass
        s.configure('Section.TLabelframe',       background=CLR_LIGHT)
        s.configure('Section.TLabelframe.Label', font=FONT_BOLD, foreground=CLR_HEADER)
        s.configure('TButton',                   font=FONT_MAIN)

    def _build_header(self):
        hdr = tk.Frame(self.root, bg=CLR_HEADER, height=52)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        tk.Label(hdr, text="보안 외부 동향 작성 툴",
                 font=FONT_TITLE, fg='white', bg=CLR_HEADER
                 ).pack(side='left', padx=18, pady=10)
        _, yesterday = get_dates()
        tk.Label(hdr, text="by HKM",
                 font=FONT_MAIN, fg='#7ab8e8', bg=CLR_HEADER
                 ).pack(side='right', padx=(0, 18))
        tk.Label(hdr, text=f"기준일: {yesterday.strftime('%Y-%m-%d')}",
                 font=FONT_MAIN, fg='#aad4f5', bg=CLR_HEADER
                 ).pack(side='right', padx=(0, 8))

    def _build_scrollable_body(self):
        container = tk.Frame(self.root, bg=CLR_LIGHT)
        container.pack(fill='both', expand=True)

        canvas = tk.Canvas(container, highlightthickness=0, bg=CLR_LIGHT)
        scrollbar = ttk.Scrollbar(container, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        self.body = tk.Frame(canvas, bg=CLR_LIGHT)
        win_id = canvas.create_window((0, 0), window=self.body, anchor='nw')

        self.body.bind('<Configure>',
                       lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',
                    lambda e: canvas.itemconfig(win_id, width=e.width))
        canvas.bind_all('<MouseWheel>',
                        lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), 'units'))

        self._build_sec1()
        self._build_sec2()
        self._build_sec3()
        self._build_sec4()
        self._build_sec5()

    # ══════════════════════════════════════════════════════════
    # 섹션 1 — 보안뉴스 (Crawl + 드롭다운 선택)
    # ══════════════════════════════════════════════════════════

    def _build_sec1(self):
        lf = ttk.LabelFrame(self.body, text="1. 보안뉴스",
                            style='Section.TLabelframe', padding=10)
        lf.pack(fill='x', padx=14, pady=8)

        # 컨트롤 행
        ctrl = tk.Frame(lf, bg=CLR_LIGHT)
        ctrl.pack(fill='x')
        self.btn_crawl1 = ttk.Button(ctrl, text="  Crawl  ",
                                      command=self._crawl_news, width=10)
        self.btn_crawl1.pack(side='left')
        self.lbl_news_st = tk.Label(ctrl, text="버튼을 눌러 뉴스를 수집하세요.",
                                     font=FONT_MAIN, fg='gray', bg=CLR_LIGHT)
        self.lbl_news_st.pack(side='left', padx=10)

        # 체크박스 드롭다운
        self.news_dd = CheckboxDropdown(lf, on_change=self._on_news_confirmed,
                                         width=30, bg=CLR_LIGHT)
        self.news_dd.pack(fill='x', pady=(8, 2))
        self.news_dd._btn.config(state='disabled')

        # 선택된 기사 미리보기
        ttk.Separator(lf).pack(fill='x', pady=4)
        preview_hdr = tk.Frame(lf, bg=CLR_LIGHT)
        preview_hdr.pack(fill='x')
        tk.Label(preview_hdr, text="선택된 기사 목록",
                 font=FONT_BOLD, fg=CLR_ACCENT, bg=CLR_LIGHT).pack(side='left')
        ttk.Button(preview_hdr, text="선택 제거",
                   command=self._remove_news, width=8).pack(side='right')

        self.news_lb = tk.Listbox(
            lf, height=5, font=FONT_MONO, selectmode='single',
            activestyle='none', bd=1, relief='sunken', bg='white',
            selectbackground='#c0d8f0'
        )
        self.news_lb.pack(fill='x', pady=(2, 0))

    def _crawl_news(self):
        def task():
            self._ui(self.btn_crawl1, 'disabled', '수집 중...')
            self._status(self.lbl_news_st, '보안뉴스 수집 중...', CLR_WARN)
            try:
                news = crawl_boannews()
                items = [{'label': f"[{n['time']}]  {n['title']}", 'data': n}
                         for n in news]
                self.root.after(0, lambda: self._news_crawled(items, len(news)))
            except Exception as e:
                self._status(self.lbl_news_st, f'오류: {e}', CLR_ERR)
            finally:
                self._ui(self.btn_crawl1, 'normal', '  Crawl  ')
        threading.Thread(target=task, daemon=True).start()

    def _news_crawled(self, items, count):
        self.news_dd.set_items(items)
        msg = (f'{count}건 수집 완료 — 드롭다운에서 포함할 기사를 선택하세요.'
               if count else '24시간 이내 기사가 없습니다.')
        self._status(self.lbl_news_st, msg, CLR_OK if count else 'gray')

    def _on_news_confirmed(self, selected):
        self.boannews_selected = selected
        self._refresh_news_lb()

    def _refresh_news_lb(self):
        self.news_lb.delete(0, 'end')
        for item in self.boannews_selected:
            self.news_lb.insert('end', f"[{item['time']}]  {item['title']}")

    def _remove_news(self):
        sel = self.news_lb.curselection()
        if not sel:
            return
        idx = sel[0]
        removed = self.boannews_selected.pop(idx)
        self.news_dd.uncheck(removed)
        self._refresh_news_lb()

    # ══════════════════════════════════════════════════════════
    # 섹션 2 — 취약점 정보 (DOCX 생성 시 자동 수집)
    # ══════════════════════════════════════════════════════════

    def _build_sec2(self):
        lf = ttk.LabelFrame(self.body,
                            text="2. 보안 권고문",
                            style='Section.TLabelframe', padding=10)
        lf.pack(fill='x', padx=14, pady=8)

        self.lbl_vuln_st = tk.Label(
            lf, text="DOCX 생성 시 전일 기준으로 자동 수집됩니다.",
            font=FONT_MAIN, fg='gray', bg=CLR_LIGHT
        )
        self.lbl_vuln_st.pack(anchor='w')

        self.vuln_lb = tk.Listbox(lf, height=4, font=FONT_MONO,
                                   bd=1, relief='sunken', bg='white',
                                   selectbackground='#c0d8f0')
        self.vuln_lb.pack(fill='x', pady=(6, 0))

    # ══════════════════════════════════════════════════════════
    # 섹션 3 — CVE 입력
    # ══════════════════════════════════════════════════════════

    def _build_sec3(self):
        lf = ttk.LabelFrame(self.body,
                            text="3. 취약점 정보 - FCTI  (TLP:GREEN 양식 붙여넣기)",
                            style='Section.TLabelframe', padding=10)
        lf.pack(fill='x', padx=14, pady=8)

        tk.Label(lf,
                 text="양식 : TLP:GREEN   CVE-XXXX-XXXXX   날짜   ➢영문설명➢한글설명   (여러 건 입력 가능)",
                 font=('맑은 고딕', 8), fg='gray', bg=CLR_LIGHT
                 ).pack(anchor='w', pady=(0, 4))

        self.cve_text = scrolledtext.ScrolledText(
            lf, height=5, font=FONT_MONO, bd=1, relief='sunken', bg='white'
        )
        self.cve_text.pack(fill='x')

        ctrl = tk.Frame(lf, bg=CLR_LIGHT)
        ctrl.pack(fill='x', pady=(4, 0))
        ttk.Button(ctrl, text="파싱", command=self._parse_cve, width=8).pack(side='left')
        self.lbl_cve_st = tk.Label(ctrl, text="", font=FONT_MAIN, fg='gray', bg=CLR_LIGHT)
        self.lbl_cve_st.pack(side='left', padx=10)

        self.cve_lb = tk.Listbox(lf, height=3, font=FONT_MONO,
                                  bd=1, relief='sunken', bg='white',
                                  selectbackground='#c0d8f0')
        self.cve_lb.pack(fill='x', pady=(4, 0))

    def _parse_cve(self):
        text = self.cve_text.get('1.0', 'end').strip()
        if not text:
            self._status(self.lbl_cve_st, '입력 데이터 없음', CLR_ERR)
            return
        self.cve_data = parse_cve_data(text)
        self.cve_lb.delete(0, 'end')
        for item in self.cve_data:
            desc = item['description'][:55] + ('...' if len(item['description']) > 55 else '')
            self.cve_lb.insert('end', f"{item['cve_id']}  ({item['date']})  {desc}")
        self._status(self.lbl_cve_st, f"{len(self.cve_data)}건 파싱 완료",
                     CLR_OK if self.cve_data else 'gray')

    # ══════════════════════════════════════════════════════════
    # 섹션 4 — Exploit-DB (DOCX 생성 시 자동 수집)
    # ══════════════════════════════════════════════════════════

    def _build_sec4(self):
        lf = ttk.LabelFrame(self.body,
                            text="4. Exploit-DB  (전일 기준, PoC 소스 제외)",
                            style='Section.TLabelframe', padding=10)
        lf.pack(fill='x', padx=14, pady=8)

        self.lbl_edb_st = tk.Label(
            lf, text="DOCX 생성 시 전일 기준으로 자동 수집됩니다.",
            font=FONT_MAIN, fg='gray', bg=CLR_LIGHT
        )
        self.lbl_edb_st.pack(anchor='w')

        self.edb_lb = tk.Listbox(lf, height=4, font=FONT_MONO,
                                  bd=1, relief='sunken', bg='white',
                                  selectbackground='#c0d8f0')
        self.edb_lb.pack(fill='x', pady=(6, 0))

    # ══════════════════════════════════════════════════════════
    # 섹션 5 — GitHub PoC (DOCX 생성 시 자동 실행)
    # ══════════════════════════════════════════════════════════

    def _build_sec5(self):
        lf = ttk.LabelFrame(self.body,
                            text="5. GitHub PoC  (git.py 실행, CVSS 7.5+)",
                            style='Section.TLabelframe', padding=10)
        lf.pack(fill='x', padx=14, pady=8)

        self.lbl_git_st = tk.Label(
            lf, text="DOCX 생성 시 자동 실행됩니다 (수 분 소요).",
            font=FONT_MAIN, fg='gray', bg=CLR_LIGHT
        )
        self.lbl_git_st.pack(anchor='w')

        self.git_lb = tk.Listbox(lf, height=4, font=FONT_MONO,
                                  bd=1, relief='sunken', bg='white',
                                  selectbackground='#c0d8f0')
        self.git_lb.pack(fill='x', pady=(6, 0))

    # ══════════════════════════════════════════════════════════
    # 하단 푸터 — 생성 버튼
    # ══════════════════════════════════════════════════════════

    def _build_footer(self):
        footer = tk.Frame(self.root, bg='#e8ecf0', bd=1, relief='ridge')
        footer.pack(fill='x', side='bottom')

        self.lbl_gen_st = tk.Label(footer, text="",
                                    font=FONT_MAIN, fg='gray', bg='#e8ecf0')
        self.lbl_gen_st.pack(side='left', padx=14, pady=8)

        self.btn_docx = ttk.Button(footer, text="DOCX + 이메일 생성",
                                    command=self._gen_all, width=20)
        self.btn_docx.pack(side='right', padx=8, pady=6)

    # ══════════════════════════════════════════════════════════
    # DOCX / 이메일 생성 (2·4·5 자동 수집 포함)
    # ══════════════════════════════════════════════════════════

    def _gen_all(self):
        self._set_gen_buttons('disabled')
        self._status(self.lbl_gen_st, '데이터 수집 및 DOCX 생성 중...', CLR_WARN)
        threading.Thread(target=self._run_gen, daemon=True).start()

    def _run_gen(self):
        """섹션 1 선택기사 본문 수집 + 섹션 2·4·5 자동수집 → DOCX + 이메일 텍스트 생성"""
        _, yesterday = get_dates()

        # ── 섹션 1: 선택된 기사 본문 수집 ─────────────────────────
        selected = self.boannews_selected
        if selected:
            total = len(selected)
            for i, article in enumerate(selected):
                if not article.get('content_html'):
                    self._status(self.lbl_news_st,
                                 f'본문 수집 중... ({i+1}/{total}건)',
                                 CLR_WARN)
                    fetch_boannews_article(article)   # in-place 업데이트
            self._status(self.lbl_news_st,
                         f'선택 기사 {total}건 본문 수집 완료', CLR_OK)

        # ── 섹션 2: 취약점 ─────────────────────────────────
        self._status(self.lbl_vuln_st, '취약점 정보 수집 중...', CLR_WARN)
        try:
            kisa   = crawl_kisa(yesterday)
            certcc = crawl_certcc(yesterday)
            self.kisa_data   = kisa
            self.certcc_data = certcc

            def _upd_vuln():
                self.vuln_lb.delete(0, 'end')
                for i in kisa:
                    self.vuln_lb.insert('end', f"[KISA]    {i['title']}")
                for i in certcc:
                    self.vuln_lb.insert('end', f"[CERT/CC] {i['title']}")
                self._status(self.lbl_vuln_st,
                             f"KISA {len(kisa)}건 / CERT/CC {len(certcc)}건 수집 완료",
                             CLR_OK)
            self.root.after(0, _upd_vuln)
        except Exception as e:
            self._status(self.lbl_vuln_st, f'오류: {e}', CLR_ERR)

        # ── 섹션 4: Exploit-DB ─────────────────────────────
        self._status(self.lbl_edb_st, 'Exploit-DB 수집 중...', CLR_WARN)
        try:
            self.exploitdb_data = crawl_exploitdb(yesterday)

            def _upd_edb():
                self.edb_lb.delete(0, 'end')
                for item in self.exploitdb_data:
                    cve = ', '.join(item.get('cves', [])) or '-'
                    self.edb_lb.insert('end', f"[{cve}]  {item['description'][:70]}")
                self._status(self.lbl_edb_st,
                             f"{len(self.exploitdb_data)}건 수집 완료", CLR_OK)
            self.root.after(0, _upd_edb)
        except Exception as e:
            self._status(self.lbl_edb_st, f'오류: {e}', CLR_ERR)

        # ── 섹션 5: GitHub PoC ─────────────────────────────
        self._status(self.lbl_git_st, 'git.py 실행 중 (수 분 소요)...', CLR_WARN)
        try:
            self.github_pocs = run_git_py()

            def _upd_git():
                self.git_lb.delete(0, 'end')
                for item in self.github_pocs:
                    self.git_lb.insert('end', f"{item['cve']}  |  {item['url']}")
                self._status(self.lbl_git_st,
                             f"{len(self.github_pocs)}건 수집 완료", CLR_OK)
            self.root.after(0, _upd_git)
        except Exception as e:
            self._status(self.lbl_git_st, f'오류: {e}', CLR_ERR)

        # ── 파일 생성 ───────────────────────────────────────
        data = {
            'date':        yesterday.strftime('%Y-%m-%d'),
            'boannews':    self.boannews_selected,
            'kisa':        self.kisa_data,
            'certcc':      self.certcc_data,
            'cve_data':    self.cve_data,
            'exploitdb':   self.exploitdb_data,
            'github_pocs': self.github_pocs,
        }

        try:
            path = create_docx(data)
            email_text = create_email_text(data)
            self._status(self.lbl_gen_st,
                         f"DOCX 저장 완료: {os.path.basename(path)}", CLR_OK)
            self.root.after(0, lambda: self._show_email_popup(email_text, path))
        except Exception as e:
            self._status(self.lbl_gen_st, f'생성 오류: {e}', CLR_ERR)
        finally:
            self.root.after(0, lambda: self._set_gen_buttons('normal'))

    # ══════════════════════════════════════════════════════════
    # 공통 유틸
    # ══════════════════════════════════════════════════════════

    def _set_gen_buttons(self, state):
        self.root.after(0, lambda: self.btn_docx.config(state=state))

    def _show_email_popup(self, email_text, docx_path):
        win = tk.Toplevel(self.root)
        win.title("이메일 본문")
        win.geometry("600x480")
        win.resizable(True, True)

        top = tk.Frame(win, bg=CLR_LIGHT, pady=6, padx=10)
        top.pack(fill='x')
        tk.Label(top, text=f"DOCX 저장: {os.path.basename(docx_path)}",
                 font=FONT_MAIN, fg=CLR_OK, bg=CLR_LIGHT).pack(side='left')
        ttk.Button(top, text="전체 복사", width=10,
                   command=lambda: self._copy_to_clipboard(win, email_text)
                   ).pack(side='right')

        txt = scrolledtext.ScrolledText(win, font=('맑은 고딕', 10),
                                         wrap='word', bd=1, relief='sunken')
        txt.pack(fill='both', expand=True, padx=10, pady=(0, 10))
        txt.insert('1.0', email_text)
        txt.config(state='normal')

    def _copy_to_clipboard(self, win, text):
        win.clipboard_clear()
        win.clipboard_append(text)
        win.update()
        messagebox.showinfo("복사 완료", "이메일 본문이 클립보드에 복사되었습니다.", parent=win)

    def _ui(self, widget, state, text=None):
        def _apply():
            widget.config(state=state)
            if text:
                widget.config(text=text)
        self.root.after(0, _apply)

    def _status(self, label, text, color='gray'):
        self.root.after(0, lambda: label.config(text=text, fg=color))


# ══════════════════════════════════════════════════════════════
# 진입점
# ══════════════════════════════════════════════════════════════
if __name__ == '__main__':
    root = tk.Tk()
    app = SecurityTrendApp(root)
    root.mainloop()

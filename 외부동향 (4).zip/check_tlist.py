﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# t_list 페이지 - 시간 포함 확인
resp = requests.get("https://www.boannews.com/media/t_list.asp", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")
print("Status:", resp.status_code, "/ HTML 길이:", len(resp.text))

date_pattern = re.compile(r"\[(\d{4})\.(\d{2})\.(\d{2})\]|(\d{2}:\d{2})")
results = []
for a in soup.find_all("a", href=True):
    text = a.get_text(strip=True)
    if re.search(r"\[\d{4}\.\d{2}\.\d{2}\]", text):
        href = a["href"]
        if not href.startswith("http"):
            href = "https://www.boannews.com" + href
        results.append((text[:80], href))

print(f"[날짜] 형식 링크 수: {len(results)}")
for t, u in results[:5]:
    print(f"  {t} | {u}")

# 시간 정보가 있는지 확인
time_tags = [t for t in soup.find_all(True) if re.search(r"\d{2}:\d{2}", t.get_text())]
print(f"\n시간 포함 태그 수: {len(time_tags)}")
for t in time_tags[:5]:
    print(f"  <{t.name}>: {t.get_text(strip=True)[:80]}")

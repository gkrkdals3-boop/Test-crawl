﻿import sys, io, requests
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# 보안뉴스
resp = requests.get("https://www.boannews.com/media/news_list.asp", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")
# 주요 클래스/태그 파악
tags = soup.find_all(class_=True)
classes = set()
for t in tags[:200]:
    for c in t.get("class", []):
        classes.add(c)
print("보안뉴스 클래스:", sorted(list(classes))[:50])

# 날짜 포함 요소 샘플
import re
date_tags = [t for t in soup.find_all(True) if re.search(r"\d{4}[.\-]\d{2}[.\-]\d{2}", t.get_text())]
print("\n날짜 포함 태그 샘플:")
for t in date_tags[:5]:
    print(f"  <{t.name} class='{t.get('class')}'>: {t.get_text(strip=True)[:80]}")

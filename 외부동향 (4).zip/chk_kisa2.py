﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
h = {"User-Agent": "Mozilla/5.0"}
href = "https://www.boho.or.kr/kr/bbs/view.do?searchCnd=&bbsId=B0000133&searchWrd=&menuNo=205020&pageIndex=1&categoryCode=&nttId=72027"
dr = requests.get(href, headers=h, timeout=15)
dr.encoding = "utf-8"
dsoup = BeautifulSoup(dr.text, "html.parser")
for sel in [".view_content",".board_view",".bbs_content","#content",".cont",".read_area",".detail_content",".view"]:
    t = dsoup.select_one(sel)
    if t:
        print(f"sel={sel}: {t.get_text(strip=True)[:150]}")
# 길이 순 div
divs = [(len(d.get_text(strip=True)), str(d.get("class","")), d.get_text(strip=True)[:80])
        for d in dsoup.find_all("div") if len(d.get_text(strip=True)) > 100]
divs.sort(key=lambda x: x[0], reverse=True)
for ln, cls, txt in divs[:6]:
    print(f"len={ln} class={cls}: {txt}")

﻿import sys, io, requests
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# 메인 페이지에서 뉴스 링크 구조 파악
resp = requests.get("https://www.boannews.com/", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")
print("Status:", resp.status_code, "/ HTML 길이:", len(resp.text))
links = soup.find_all("a", href=True)
print(f"링크 수: {len(links)}")
for l in links[:40]:
    href = l.get("href","")
    text = l.get_text(strip=True)
    if text and len(text) > 8 and ("media" in href or "news" in href.lower()):
        print(f"  {href[:80]}  |  {text[:60]}")

﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# 전체 기사 목록을 위한 다른 URL 시도
for url in [
    "https://www.boannews.com/media/t_list.asp?kind=1",
    "https://www.boannews.com/media/t_list.asp?kind=1&page=1",
    "https://www.boannews.com/media/list.asp",
]:
    resp = requests.get(url, headers=headers, timeout=15)
    resp.encoding = "euc-kr"
    soup = BeautifulSoup(resp.text, "html.parser")
    
    # view.asp 링크 개수
    view_links = [a for a in soup.find_all("a", href=True) if "view.asp" in a.get("href","")]
    date_links = [a for a in view_links if re.search(r"\[\d{4}\.\d{2}\.\d{2}\]", a.get_text())]
    
    print(f"\nURL: {url}")
    print(f"  Status: {resp.status_code} / view.asp 링크: {len(view_links)} / 날짜포함: {len(date_links)}")
    for a in date_links[:3]:
        print(f"    {a.get_text(strip=True)[:70]}")

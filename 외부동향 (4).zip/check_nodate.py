﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
resp = requests.get("https://www.boannews.com/media/t_list.asp?kind=1", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")

# view.asp 링크 중 날짜 없는 것들 주변 구조 파악
view_links = [a for a in soup.find_all("a", href=True) if "view.asp" in a.get("href","")]
no_date = [a for a in view_links if not re.search(r"\[\d{4}\.\d{2}\.\d{2}\]", a.get_text())]
print(f"날짜 없는 링크 {len(no_date)}개 샘플:")
for a in no_date[:5]:
    text = a.get_text(strip=True)
    parent = a.parent
    gp = parent.parent
    # 주변 텍스트에서 날짜 찾기
    surrounding = gp.get_text(strip=True)
    date_m = re.search(r"\d{4}\.\d{2}\.\d{2}|\d{2}\.\d{2}|\d{2}:\d{2}", surrounding)
    print(f"  제목: {text[:50]}")
    print(f"  주변텍스트: {surrounding[:100]}")
    print()

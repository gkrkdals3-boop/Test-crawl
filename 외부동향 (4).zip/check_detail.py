﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# 기사 상세 페이지에서 날짜 확인
resp = requests.get("https://www.boannews.com/media/view.asp?idx=143403&kind=2", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")
print("Status:", resp.status_code)

# 날짜/시간 태그 탐색
date_re = re.compile(r"\d{4}[.\-/]\d{2}[.\-/]\d{2}")
time_re = re.compile(r"\d{2}:\d{2}")
for tag in soup.find_all(True):
    text = tag.get_text(strip=True)
    if date_re.search(text) and len(text) < 60:
        print(f"  <{tag.name} class={tag.get('class')}> {text}")

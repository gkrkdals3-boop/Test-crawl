﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
h = {"User-Agent": "Mozilla/5.0"}

# 보안뉴스 기사 본문 구조
r = requests.get("https://www.boannews.com/media/view.asp?idx=143403&kind=2", headers=h, timeout=15)
r.encoding = "euc-kr"
soup = BeautifulSoup(r.text, "html.parser")
print("=== 보안뉴스 본문 후보 ===")
for sel in ["#news_content","#article","div.news_content","div.content_area",".view_content","div.view","#view_txt"]:
    t = soup.select_one(sel)
    if t:
        print(f"  선택자={sel}: {t.get_text(strip=True)[:100]}")

# 본문 길이 상위 5개 div
divs = [(len(d.get_text(strip=True)), d.get("class"), d.get_text(strip=True)[:80])
        for d in soup.find_all("div") if len(d.get_text(strip=True)) > 200]
divs.sort(reverse=True)
for ln, cls, txt in divs[:5]:
    print(f"  len={ln} class={cls}: {txt}")

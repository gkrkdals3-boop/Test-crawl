﻿import sys, io, requests
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
resp = requests.get("https://www.boannews.com/media/news_list.asp", headers=headers, timeout=15)
resp.encoding = "euc-kr"
print("Status:", resp.status_code)
print("Content-Type:", resp.headers.get("Content-Type"))
print("HTML 전체:")
print(resp.text)

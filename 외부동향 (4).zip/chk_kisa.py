﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
h = {"User-Agent": "Mozilla/5.0"}

# KISA 상세 페이지 본문 구조 확인
r = requests.get("https://www.boho.or.kr/kr/bbs/list.do?menuNo=205020&bbsId=B0000133", headers=h, timeout=15)
r.encoding = "utf-8"
soup = BeautifulSoup(r.text, "html.parser")
# 첫 번째 링크 href 가져오기
a = soup.select_one("table tbody tr a")
if a:
    href = a.get("href","")
    if not href.startswith("http"): href = "https://www.boho.or.kr" + href
    print(f"KISA 상세 URL: {href}")
    dr = requests.get(href, headers=h, timeout=15)
    dr.encoding = "utf-8"
    dsoup = BeautifulSoup(dr.text, "html.parser")
    print("=== KISA 본문 후보 ===")
    for sel in [".view_content",".board_view",".bbs_content","#content",".cont","div.view",".read_area",".detail_content"]:
        t = dsoup.select_one(sel)
        if t:
            print(f"  선택자={sel}: {t.get_text(strip=True)[:120]}")
    divs = [(len(d.get_text(strip=True)), d.get("class"), d.get_text(strip=True)[:80])
            for d in dsoup.find_all("div") if len(d.get_text(strip=True)) > 100]
    divs.sort(reverse=True)
    for ln, cls, txt in divs[:5]:
        print(f"  len={ln} class={cls}: {txt}")

﻿import sys, io, requests
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
resp = requests.get("https://www.boannews.com/media/news_list.asp", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")

# 전체 body 구조 중 뉴스 리스트 영역 파악
body = soup.body
print("전체 HTML 길이:", len(resp.text))
# a 태그 중 뉴스 링크 샘플
links = soup.find_all("a", href=True)
print(f"\n총 링크 수: {len(links)}")
for l in links[:30]:
    href = l.get("href","")
    text = l.get_text(strip=True)
    if text and len(text) > 10:
        print(f"  href={href[:60]}  text={text[:60]}")

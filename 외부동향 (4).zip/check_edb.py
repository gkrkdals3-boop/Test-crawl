﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# Exploit-DB API 응답 확인
import json
from datetime import datetime, timedelta
yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")

ajax_headers = {**headers,
    "X-Requested-With": "XMLHttpRequest",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Referer": "https://www.exploit-db.com/",
}
params = {
    "draw": "1",
    "columns[0][data]": "date_published", "columns[0][name]": "date_published",
    "columns[1][data]": "download", "columns[1][name]": "download",
    "columns[2][data]": "application_md5", "columns[2][name]": "application_md5",
    "columns[3][data]": "verified", "columns[3][name]": "verified",
    "columns[4][data]": "is_webapps", "columns[4][name]": "is_webapps",
    "columns[5][data]": "type", "columns[5][name]": "type",
    "columns[6][data]": "platform", "columns[6][name]": "platform",
    "columns[7][data]": "author", "columns[7][name]": "author",
    "columns[8][data]": "description", "columns[8][name]": "description",
    "order[0][column]": "0", "order[0][dir]": "desc",
    "start": "0", "length": "20",
    "search[value]": "", "search[regex]": "false",
    "author": "", "type": "", "platform": "",
    "daterange": f"{yesterday} - {yesterday}",
    "verified": "",
}
resp = requests.get("https://www.exploit-db.com/search", headers=ajax_headers, params=params, timeout=20)
print(f"Status: {resp.status_code}")
print(f"Content-Type: {resp.headers.get('Content-Type')}")
print(f"응답 앞 500자: {resp.text[:500]}")

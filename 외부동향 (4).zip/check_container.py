﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
resp = requests.get("https://www.boannews.com/media/t_list.asp?kind=1", headers=headers, timeout=15)
resp.encoding = "euc-kr"
soup = BeautifulSoup(resp.text, "html.parser")

# 기사 제목+날짜 함께 있는 li/div/tr 블록 찾기
# 날짜 패턴: YYYY.MM.DD 또는 YYYY-MM-DD
date_re = re.compile(r"\d{4}[.\-]\d{2}[.\-]\d{2}")

containers = []
for tag in soup.find_all(["li", "div", "tr", "article"]):
    text = tag.get_text(strip=True)
    if date_re.search(text) and tag.find("a", href=lambda h: h and "view.asp" in h):
        # 너무 큰 컨테이너 제외
        children_with_view = tag.find_all("a", href=lambda h: h and "view.asp" in h)
        if 1 <= len(children_with_view) <= 2:
            containers.append(tag)

print(f"기사 컨테이너 후보: {len(containers)}개")
for c in containers[:3]:
    txt = c.get_text(strip=True)
    a = c.find("a", href=lambda h: h and "view.asp" in h)
    print(f"  [{c.name}] 날짜 텍스트: {txt[:120]}")
    print(f"       링크: {a.get('href') if a else '-'}")
    print()

﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# RSS 피드 시도
for rss_url in [
    "https://www.boannews.com/rss/rss.xml",
    "https://www.boannews.com/rss/",
    "https://www.boannews.com/media/rss.asp",
]:
    try:
        resp = requests.get(rss_url, headers=headers, timeout=10)
        print(f"{rss_url}: {resp.status_code} / {len(resp.text)}bytes / Content-Type: {resp.headers.get('Content-Type','')}")
        if resp.status_code == 200 and len(resp.text) > 1000:
            print("  내용 미리보기:", resp.text[:300])
            break
    except Exception as e:
        print(f"{rss_url}: 오류 - {e}")

# t_list 전체 기사 목록 - 날짜 없는 기사들의 HTML 구조 확인
resp2 = requests.get("https://www.boannews.com/media/t_list.asp?kind=1", headers=headers, timeout=15)
resp2.encoding = "euc-kr"
soup = BeautifulSoup(resp2.text, "html.parser")

# li 태그들 전체 구조 파악
lis = soup.find_all("li")
print(f"\n총 li 태그: {len(lis)}")
# view.asp 포함 li
view_lis = [li for li in lis if li.find("a", href=lambda h: h and "view.asp" in h)]
print(f"view.asp 포함 li: {len(view_lis)}")
# 샘플 출력
for li in view_lis[:5]:
    print(f"\n  li 내용: {li.get_text(strip=True)[:100]}")
    for a in li.find_all("a"):
        print(f"    a: href={a.get('href','')} | text={a.get_text(strip=True)[:50]}")

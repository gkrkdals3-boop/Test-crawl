﻿import sys, io, requests, re
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
resp = requests.get("https://www.kb.cert.org/vuls/", headers=headers, timeout=15)
soup = BeautifulSoup(resp.text, "html.parser")

# h6 태그 주변 구조 파악
for h6 in soup.find_all("h6")[:3]:
    print(f"=== h6: {h6.get_text(strip=True)} ===")
    parent = h6.parent
    print(f"  부모: <{parent.name} class={parent.get('class')}>")
    # 형제 요소들
    for sib in parent.children:
        if hasattr(sib, 'name') and sib.name:
            t = sib.get_text(strip=True)[:100]
            a = sib.find("a")
            print(f"    <{sib.name} class={sib.get('class')}> {t[:80]}")
            if a:
                print(f"      링크: {a.get('href')} | {a.get_text(strip=True)[:60]}")

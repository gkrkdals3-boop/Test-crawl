#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
보안 외부 동향 보고서 자동 생성기
- 1. 보안뉴스 (boannews.com, 24시간 이내)
- 2. 취약점 정보 (KISA 보호나라 + CERT/CC, 전일 기준)
- 3. CVE 상세 정보 (사용자 입력 파싱)
- 4. Exploit-DB (전일 기준)
- 5. GitHub PoC (git.py 실행 결과)
"""
import sys, io

# stdout 리디렉션은 CLI 직접 실행 시에만 적용 (GUI에서 import할 때는 skip)
if __name__ == '__main__':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except Exception:
        pass

import subprocess
import sys
import re
import os
import json
import copy
import base64
import uuid
from urllib.parse import urljoin
from datetime import datetime, timedelta, timezone
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
_orig_get  = requests.get
_orig_post = requests.post
requests.get  = lambda *a, **kw: _orig_get(*a,  **{**kw, 'verify': False})
requests.post = lambda *a, **kw: _orig_post(*a, **{**kw, 'verify': False})
from bs4 import BeautifulSoup
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.opc.part import Part
from docx.opc.packuri import PackURI
import pytz

_AFCHUNK_REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/aFChunk'

try:
    from htmldocx import HtmlToDocx
    _HTMLDOCX = True
except ImportError:
    _HTMLDOCX = False

KST = pytz.timezone('Asia/Seoul')

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
}


def _load_github_headers():
    """git.py 에서 GitHub 토큰을 읽어 API 헤더 반환"""
    try:
        git_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'git.py')
        with open(git_path, 'r', encoding='utf-8') as f:
            content = f.read()
        m = re.search(r"github_token\s*=\s*['\"]([^'\"]+)['\"]", content)
        if m:
            return {
                'Accept': 'application/vnd.github.v3+json',
                'Authorization': f'Bearer {m.group(1)}',
            }
    except Exception:
        pass
    return {'Accept': 'application/vnd.github.v3+json'}


_GH_HEADERS = _load_github_headers()


_README_CACHE: dict = {}


def _fetch_readme_title(url):
    """GitHub 레포 README 의 첫 번째 # 제목 반환. 실패 시 None. 결과 캐시."""
    if url in _README_CACHE:
        return _README_CACHE[url]
    result = None
    try:
        parts = url.rstrip('/').split('/')
        if len(parts) >= 5:
            owner, repo = parts[-2], parts[-1]
            api_url = f'https://api.github.com/repos/{owner}/{repo}/readme'
            r = requests.get(api_url, headers=_GH_HEADERS, timeout=8)
            if r.status_code == 200:
                raw = base64.b64decode(r.json().get('content', '')).decode('utf-8', errors='replace')
                for line in raw.splitlines():
                    line = line.strip()
                    if line.startswith('#'):
                        title = line.lstrip('#').strip()
                        if title:
                            result = title
                            break
    except Exception:
        pass
    _README_CACHE[url] = result
    return result


def get_dates():
    now = datetime.now(KST)
    yesterday = now - timedelta(days=1)
    return now, yesterday


# ============================================================
# 공통 유틸
# ============================================================

def parse_korean_datetime(text, ref_now):
    """한국어 상대/절대 시간 표현 → datetime(KST) 변환"""
    text = text.strip()

    m = re.search(r'(\d+)분\s*전', text)
    if m:
        return ref_now - timedelta(minutes=int(m.group(1)))

    m = re.search(r'(\d+)시간\s*전', text)
    if m:
        return ref_now - timedelta(hours=int(m.group(1)))

    m = re.search(r'(\d+)일\s*전', text)
    if m:
        return ref_now - timedelta(days=int(m.group(1)))

    # YYYY.MM.DD HH:MM 또는 YYYY-MM-DD HH:MM
    m = re.search(r'(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})\s+(\d{1,2}):(\d{2})', text)
    if m:
        try:
            dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                          int(m.group(4)), int(m.group(5)))
            return KST.localize(dt)
        except ValueError:
            pass

    # YYYY.MM.DD 또는 YYYY-MM-DD
    m = re.search(r'(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})', text)
    if m:
        try:
            dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return KST.localize(dt)
        except ValueError:
            pass

    return None


def parse_english_date(text):
    """영어 날짜 문자열 → 'YYYY-MM-DD' 반환"""
    months = {
        'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
        'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
        'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
    }

    # ISO 형식
    m = re.search(r'(\d{4})-(\d{2})-(\d{2})', text)
    if m:
        return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"

    # "April 27, 2026" / "27 April 2026"
    tl = text.lower()
    for short, num in months.items():
        if short in tl:
            m = re.search(r'(\d{1,2})\D+(\d{4})', tl)
            if m:
                return f"{m.group(2)}-{num}-{m.group(1).zfill(2)}"
            m = re.search(r'(\d{4})\D+(\d{1,2})', tl)
            if m:
                return f"{m.group(1)}-{num}-{m.group(2).zfill(2)}"

    return None


# ============================================================
# 1. 보안뉴스 크롤링 (24시간 이내)
# ============================================================

def crawl_boannews():
    """보안뉴스 24시간 이내 기사 크롤링
    - 목록 페이지에서 view.asp idx 수집
    - 각 기사 상세 페이지의 '입력 : YYYY-MM-DD HH:MM' 에서 시간 확인
    """
    results = []
    now = datetime.now(KST)
    cutoff = now - timedelta(hours=24)
    base_url = "https://www.boannews.com"

    # 목록 페이지에서 idx + 제목 수집
    idx_title = {}
    try:
        resp = requests.get(f"{base_url}/media/t_list.asp?kind=1", headers=HEADERS, timeout=15)
        resp.encoding = 'euc-kr'
        soup = BeautifulSoup(resp.text, 'html.parser')
        for a in soup.find_all('a', href=True):
            href = a['href']
            m = re.search(r'idx=(\d+)', href)
            if m:
                idx = int(m.group(1))
                text = a.get_text(strip=True)
                # [날짜] 제거한 순수 제목
                title = re.sub(r'^\[\d{4}\.\d{2}\.\d{2}\]', '', text).strip()
                if title and idx not in idx_title:
                    idx_title[idx] = (title, href)
    except Exception as e:
        print(f"  [!] 보안뉴스 목록 수집 실패: {e}")
        return results

    # idx 내림차순으로 정렬 → 최신 기사부터 확인
    sorted_idxs = sorted(idx_title.keys(), reverse=True)[:50]

    for idx in sorted_idxs:
        title, href = idx_title[idx]
        if not href.startswith('http'):
            href = base_url + ('/' if not href.startswith('/') else '') + href
        try:
            dr = requests.get(href, headers=HEADERS, timeout=10)
            dr.encoding = 'euc-kr'
            dsoup = BeautifulSoup(dr.text, 'html.parser')
            # '입력 : YYYY-MM-DD HH:MM' 패턴 탐색
            pub_time = None
            for tag in dsoup.find_all(True):
                t = tag.get_text(strip=True)
                m = re.search(r'입력\s*[：:]\s*(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})', t)
                if m and len(list(tag.children)) <= 3:
                    pub_time = parse_korean_datetime(m.group(1), now)
                    break
            if pub_time is None:
                continue
            if pub_time < cutoff:
                break

            # 타임스탬프만 수집 (본문은 사용자 선택 후 별도 수집)
            results.append({
                'title': title,
                'url': href,
                'time': pub_time.strftime('%Y-%m-%d %H:%M'),
            })
        except Exception:
            continue

    return results


def fetch_boannews_article(article):
    """선택된 기사 1건의 본문 HTML을 크롤링하여 article dict에 추가 (in-place)"""
    base_url = 'https://www.boannews.com'
    try:
        dr = requests.get(article['url'], headers=HEADERS, timeout=10)
        dr.encoding = 'euc-kr'
        dsoup = BeautifulSoup(dr.text, 'html.parser')
        content_tag = dsoup.select_one('#news_content')
        if content_tag:
            for img in content_tag.find_all('img', src=True):
                src = img.get('src', '')
                if src and not src.startswith(('http', 'data:')):
                    img['src'] = urljoin(base_url, src)
            article['content_html'] = str(content_tag)
            article['content'] = content_tag.get_text(separator='\n', strip=True)
    except Exception:
        pass
    return article


# ============================================================
# 2. 취약점 정보 크롤링
# ============================================================

def crawl_kisa(target_date):
    """KISA 보호나라 취약점 게시판 크롤링"""
    results = []
    date_str = target_date.strftime('%Y-%m-%d')
    url = "https://www.boho.or.kr/kr/bbs/list.do?menuNo=205020&bbsId=B0000133"

    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.encoding = 'utf-8'
        soup = BeautifulSoup(resp.text, 'html.parser')

        rows = soup.select('table tbody tr')
        for row in rows:
            cols = row.find_all('td')
            if not cols:
                continue

            # 날짜 컬럼 탐색
            row_text = row.get_text()
            date_match = re.search(r'(\d{4})[.\-](\d{2})[.\-](\d{2})', row_text)
            if not date_match:
                continue
            row_date = f"{date_match.group(1)}-{date_match.group(2)}-{date_match.group(3)}"
            if row_date != date_str:
                continue

            link_tag = row.select_one('a')
            if not link_tag:
                continue
            title = link_tag.get_text(strip=True)
            href = link_tag.get('href', '')
            if href and not href.startswith('http'):
                href = 'https://www.boho.or.kr' + href

            content = ''
            content_html = ''
            try:
                dr = requests.get(href, headers=HEADERS, timeout=10)
                dr.encoding = 'utf-8'
                dsoup = BeautifulSoup(dr.text, 'html.parser')
                ct = dsoup.select_one('div.content')
                if ct:
                    # SNS 공유 버튼 제거
                    for unwanted in ct.find_all(
                        class_=lambda c: c and any(
                            x in ' '.join(c if isinstance(c, list) else [c]).lower()
                            for x in ['share', 'sns', 'social']
                        )
                    ):
                        unwanted.decompose()
                    for img in ct.find_all('img', src=True):
                        src = img.get('src', '')
                        if src and not src.startswith(('http', 'data:')):
                            img['src'] = urljoin('https://www.boho.or.kr', src)
                    content_html = str(ct)
                    content = ct.get_text(separator='\n', strip=True)
            except Exception:
                pass

            results.append({
                'title': title,
                'url': href,
                'date': date_str,
                'source': 'KISA 보호나라',
                'content': content,
                'content_html': content_html
            })

    except Exception as e:
        print(f"  [!] KISA 크롤링 실패: {e}")

    return results


def crawl_certcc(target_date):
    """CERT/CC Vulnerability Notes 크롤링
    구조: <div class='vulnerability-list'>
            <h4><a href='/vuls/id/XXXXXX'>제목</a></h4>
            <h6>Month DD, YYYY</h6>
          </div>
    """
    results = []
    date_str = target_date.strftime('%Y-%m-%d')

    url = "https://www.kb.cert.org/vuls/"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        soup = BeautifulSoup(resp.text, 'html.parser')

        for block in soup.select('div.vulnerability-list'):
            h6 = block.find('h6')
            if not h6:
                continue
            parsed_date = parse_english_date(h6.get_text(strip=True))
            if not parsed_date or parsed_date != date_str:
                continue

            link_tag = block.find('a', href=True)
            if not link_tag:
                continue
            title = link_tag.get_text(strip=True)
            href = link_tag['href']
            if not href.startswith('http'):
                href = 'https://www.kb.cert.org' + href

            cves = re.findall(r'CVE-\d{4}-\d+', block.get_text())

            content = ''
            content_html = ''
            try:
                dr = requests.get(href, headers=HEADERS, timeout=10)
                dsoup = BeautifulSoup(dr.text, 'html.parser')
                ct = (dsoup.select_one('div.vuid-content') or
                      dsoup.select_one('div#content') or
                      dsoup.select_one('main'))
                if ct:
                    for img in ct.find_all('img', src=True):
                        src = img.get('src', '')
                        if src and not src.startswith(('http', 'data:')):
                            img['src'] = urljoin('https://www.kb.cert.org', src)
                    content_html = str(ct)
                    content = ct.get_text(separator='\n', strip=True)
            except Exception:
                pass

            results.append({
                'title': title,
                'url': href,
                'date': date_str,
                'cves': cves,
                'source': 'CERT/CC',
                'content': content,
                'content_html': content_html
            })

    except Exception as e:
        print(f"  [!] CERT/CC 크롤링 실패: {e}")

    return results


# ============================================================
# 3. 사용자 입력 CVE 파싱
# ============================================================

def parse_cve_input():
    """TLP:GREEN 양식 CVE 데이터를 stdin으로 입력받아 파싱"""
    print()
    print("=" * 60)
    print("[3] CVE 데이터 입력")
    print("양식: TLP:GREEN  CVE-XXXX-XXXXX  날짜  ➢영문설명➢한글설명")
    print("여러 항목 입력 가능.")
    print("입력 완료: 빈 줄에서 Enter 두 번 (또는 Ctrl+Z → Enter)")
    print("=" * 60)

    lines = []
    blank_count = 0
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line.strip() == '':
            blank_count += 1
            if blank_count >= 2:
                break
        else:
            blank_count = 0
            lines.append(line)

    return parse_cve_data('\n'.join(lines))


def parse_cve_data(text):
    """TLP:GREEN 양식 텍스트에서 CVE 목록 추출"""
    results = []
    if not text.strip():
        return results

    # TLP: 키워드 기준으로 각 항목 분리
    entries = re.split(r'(?=TLP\s*:)', text.strip(), flags=re.IGNORECASE)

    for entry in entries:
        entry = entry.strip()
        if not entry:
            continue

        cve_m = re.search(r'(CVE-\d{4}-\d+)', entry, re.IGNORECASE)
        if not cve_m:
            continue
        cve_id = cve_m.group(1).upper()

        date_m = re.search(r'(\d{4}-\d{2}-\d{2})', entry)
        date = date_m.group(1) if date_m else ''

        # 영문 설명: 첫 ➢ ~ 두 번째 ➢ 사이
        desc_m = re.search(r'➢(.+?)➢', entry, re.DOTALL)
        if desc_m:
            english_desc = desc_m.group(1).strip()
        else:
            # ➢ 가 하나만 있는 경우 이후 전체
            single_m = re.search(r'➢(.+)', entry, re.DOTALL)
            english_desc = single_m.group(1).strip() if single_m else ''

        results.append({
            'cve_id': cve_id,
            'date': date,
            'description': english_desc
        })

    return results


# ============================================================
# 4. Exploit-DB 크롤링
# ============================================================

def _enrich_exploitdb_cve(item):
    """CVE가 비어있는 항목만 상세 페이지에서 CVE 코드 추출"""
    if item.get('cves'):
        return
    try:
        r = requests.get(item['url'], headers=HEADERS, timeout=8)
        if r.status_code == 200:
            found = list(dict.fromkeys(
                c.upper() for c in re.findall(r'CVE-\d{4}-\d+', r.text, re.I)
            ))
            if found:
                item['cves'] = found
    except Exception:
        pass


def crawl_exploitdb(target_date):
    """Exploit-DB 전일 취약점 크롤링 (PoC 소스코드 제외, CVE 포함)"""
    from concurrent.futures import ThreadPoolExecutor
    date_str = target_date.strftime('%Y-%m-%d')

    # 방법 1: DataTables AJAX API
    results = _exploitdb_ajax(date_str)
    if not results:
        # 방법 2: HTML 직접 파싱 (fallback)
        results = _exploitdb_html(date_str)

    # CVE 없는 항목만 상세 페이지에서 보완 (병렬)
    missing = [it for it in results if not it.get('cves')]
    if missing:
        with ThreadPoolExecutor(max_workers=5) as ex:
            list(ex.map(_enrich_exploitdb_cve, missing))

    return results


def _exploitdb_ajax(date_str):
    """Exploit-DB DataTables AJAX 엔드포인트
    - API daterange 파라미터가 서버에서 무시되므로 Python에서 직접 필터링
    - 최신 100건을 받아 date_published == date_str 인 것만 추출
    """
    results = []
    url = "https://www.exploit-db.com/search"

    params = {
        "draw": "1",
        "columns[0][data]": "date_published", "columns[0][name]": "date_published",
        "columns[0][searchable]": "true", "columns[0][orderable]": "true",
        "columns[0][search][value]": "", "columns[0][search][regex]": "false",
        "columns[1][data]": "download", "columns[1][name]": "download",
        "columns[2][data]": "application_md5", "columns[2][name]": "application_md5",
        "columns[3][data]": "verified", "columns[3][name]": "verified",
        "columns[4][data]": "is_webapps", "columns[4][name]": "is_webapps",
        "columns[5][data]": "type", "columns[5][name]": "type",
        "columns[6][data]": "platform", "columns[6][name]": "platform",
        "columns[7][data]": "author", "columns[7][name]": "author",
        "columns[8][data]": "description", "columns[8][name]": "description",
        "order[0][column]": "0", "order[0][dir]": "desc",
        "start": "0", "length": "100",
        "search[value]": "", "search[regex]": "false",
        "author": "", "type": "", "platform": "",
        "daterange": f"{date_str} - {date_str}",
        "verified": "",
    }

    ajax_headers = {
        **HEADERS,
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Referer": "https://www.exploit-db.com/",
    }

    try:
        resp = requests.get(url, headers=ajax_headers, params=params, timeout=20)
        if resp.status_code != 200:
            return []

        data = resp.json()
        exploits = data.get('data', [])

        for exp in exploits:
            pub_date = str(exp.get('date_published', ''))
            # Python 레벨에서 날짜 필터링
            if pub_date != date_str:
                continue

            exp_id = exp.get('id', '')

            # description 은 리스트 or 문자열
            raw_desc = exp.get('description', '')
            if isinstance(raw_desc, list):
                raw_desc = ' '.join(str(x) for x in raw_desc)
            description = BeautifulSoup(str(raw_desc), 'html.parser').get_text(strip=True)
            # idx 접두어 제거 (Exploit-DB 응답에 종종 "52510 제목" 형식)
            description = re.sub(r'^\d+\s+', '', description).strip()

            platform_raw = exp.get('platform', '')
            platform = platform_raw.get('platform', '') if isinstance(platform_raw, dict) else str(platform_raw)

            author_raw = exp.get('author', '')
            author = author_raw.get('name', '') if isinstance(author_raw, dict) else str(author_raw)

            # CVE 추출
            cves = []
            for code_obj in exp.get('codes', []) or []:
                code_str = code_obj.get('code', '') if isinstance(code_obj, dict) else str(code_obj)
                if re.match(r'CVE-\d{4}-\d+', code_str, re.I):
                    cves.append(code_str.upper())

            results.append({
                'id': exp_id,
                'description': description,
                'type': exp.get('type', {}).get('display', '') if isinstance(exp.get('type'), dict) else str(exp.get('type', '')),
                'platform': platform,
                'author': author,
                'date': pub_date,
                'cves': cves,
                'url': f"https://www.exploit-db.com/exploits/{exp_id}"
            })

    except Exception as e:
        print(f"  [!] Exploit-DB AJAX 실패: {e}")

    return results


def _exploitdb_html(date_str):
    """Exploit-DB HTML fallback 파싱"""
    results = []
    url = "https://www.exploit-db.com/"

    try:
        resp = requests.get(url, headers=HEADERS, timeout=20)
        soup = BeautifulSoup(resp.text, 'html.parser')

        rows = soup.select('#exploits-table tbody tr') or soup.select('table tbody tr')
        for row in rows:
            cols = row.find_all('td')
            if not cols:
                continue
            row_text = row.get_text(' ', strip=True)
            if date_str not in row_text:
                continue

            link_tag = row.select_one('a')
            if not link_tag:
                continue
            description = link_tag.get_text(strip=True)
            href = link_tag.get('href', '')
            if href and not href.startswith('http'):
                href = 'https://www.exploit-db.com' + href

            cves = re.findall(r'CVE-\d{4}-\d+', row_text, re.I)
            cves = [c.upper() for c in cves]

            results.append({
                'id': '',
                'description': description,
                'type': '',
                'platform': '',
                'author': '',
                'date': date_str,
                'cves': cves,
                'url': href
            })

    except Exception as e:
        print(f"  [!] Exploit-DB HTML 파싱 실패: {e}")

    return results


# ============================================================
# 5. git.py 실행 및 결과 파싱
# ============================================================

def _safe_print(msg):
    """stdout이 닫혀 있어도 안전하게 출력"""
    try:
        print(msg)
    except Exception:
        pass


def run_git_py():
    """git.py 실행 후 출력 파싱"""
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'git.py')

    if not os.path.exists(script_path):
        _safe_print(f"  [!] git.py를 찾을 수 없습니다: {script_path}")
        return []

    _safe_print("  (수 분 소요될 수 있습니다...)")
    try:
        # encoding 지정 없이 bytes로 받아 직접 디코딩 (git.py 출력이 CP949)
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        result = subprocess.run(
            [sys.executable, script_path],
            capture_output=True,
            timeout=1200,
            env=env
        )
        raw_out = result.stdout or b''
        raw_err = result.stderr or b''
        # UTF-8 우선, 실패 시 CP949로 디코딩
        try:
            output = raw_out.decode('utf-8', errors='replace')
        except Exception:
            output = raw_out.decode('cp949', errors='replace')
        if result.returncode != 0 and raw_err:
            err_text = raw_err.decode('utf-8', errors='replace')
            _safe_print(f"  [!] git.py stderr: {err_text[:300]}")
        return _parse_git_output(output)

    except subprocess.TimeoutExpired:
        _safe_print("  [!] git.py 타임아웃 (20분 초과)")
        return []
    except Exception as e:
        _safe_print(f"  [!] git.py 실행 실패: {e}")
        return []


def _parse_git_output(output):
    """git.py stdout을 파싱하여 PoC 목록 반환"""
    results = []
    blocks = re.split(r'(?=5-\d+\.)', output)
    for block in blocks:
        block = block.strip()
        if not re.match(r'5-\d+\.', block):
            continue
        cve_m = re.search(r'CVE ID\s*:\s*(CVE-\d{4}-\d+)', block, re.I)
        link_m = re.search(r'Link\s*:\s*(https?://\S+)', block, re.I)
        if cve_m and link_m:
            results.append({
                'cve': cve_m.group(1).upper(),
                'url': link_m.group(1).rstrip('.,)'),
                'content': '유의미한 코드 업데이트 감지됨'
            })
    return results


# ============================================================
# DOCX 생성 헬퍼
# ============================================================

def _set_cell_bg(cell, hex_color):
    """표 셀 배경색 설정"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)


def _add_section_heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(16)
    r.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
    r.font.name = '맑은 고딕'
    return p


def _add_table_row(table, cells_text, bold=False, bg_color=None):
    row = table.add_row()
    for i, text in enumerate(cells_text):
        cell = row.cells[i]
        cell.text = text
        if bold:
            for run in cell.paragraphs[0].runs:
                run.bold = True
        if bg_color:
            _set_cell_bg(cell, bg_color)
    return row


def _add_html_to_cell_safe(cell, html_str, fallback_text=''):
    """HTML을 table cell에 삽입. 이미지는 HEADERS로 직접 다운로드하여 삽입."""
    if _HTMLDOCX and html_str:
        try:
            # 이미지 src별로 bytes 사전 다운로드 (User-Agent/Referer 포함)
            soup_tmp = BeautifulSoup(html_str, 'html.parser')
            image_cache = {}
            for img in soup_tmp.find_all('img', src=True):
                src = img.get('src', '')
                if src.startswith('http') and src not in image_cache:
                    try:
                        r = requests.get(src, headers=HEADERS, timeout=8)
                        if r.status_code == 200 and r.content:
                            image_cache[src] = r.content
                    except Exception:
                        pass

            # htmldocx 내부 requests.get을 캐시 응답으로 대체
            import htmldocx.htmldocx as _hd
            _orig = _hd.requests.get

            def _cached_get(url, *a, **kw):
                if url in image_cache:
                    class _R:
                        status_code = 200
                        content = image_cache[url]
                    return _R()
                return _orig(url, *a, **kw)

            _hd.requests.get = _cached_get
            try:
                temp_doc = Document()
                HtmlToDocx().add_html_to_document(html_str, temp_doc)
            finally:
                _hd.requests.get = _orig

            # temp_doc body 전체(p + tbl)를 cell로 복사
            body = temp_doc.element.body
            tc = cell._tc
            for child in list(tc):
                if child.tag.endswith('}p') or child.tag.endswith('}tbl'):
                    tc.remove(child)
            for child in body:
                if child.tag.endswith('}p') or child.tag.endswith('}tbl'):
                    tc.append(copy.deepcopy(child))
            if not any(c.tag.endswith('}p') for c in tc):
                tc.append(OxmlElement('w:p'))
            return
        except Exception:
            pass
    p = cell.paragraphs[0] if cell.paragraphs else cell.add_paragraph()
    if not p.runs:
        p.add_run(fallback_text or '').font.size = Pt(9)
    else:
        p.runs[0].text = fallback_text or ''


def _make_box_html(inner_html, url):
    """본문 HTML을 1×1 테두리 박스로 감싸고 원문 URL을 맨 아래에 추가"""
    return (
        '<table style="border:1px solid #999;border-collapse:collapse;width:100%;">'
        '<tr><td style="padding:10px;font-size:10pt;vertical-align:top;">'
        + inner_html
        + f'<p style="margin-top:10px;font-size:8pt;color:#1a73e8;">'
          f'원문 : <a href="{url}">{url}</a></p>'
        '</td></tr></table>'
    )


def _set_table_half_width(table):
    """테이블 너비를 페이지 폭의 50%로 제한"""
    tbl_elem = table._tbl
    tblPr = tbl_elem.find(qn('w:tblPr'))
    if tblPr is None:
        tblPr = OxmlElement('w:tblPr')
        tbl_elem.insert(0, tblPr)
    for old in tblPr.findall(qn('w:tblW')):
        tblPr.remove(old)
    tblW = OxmlElement('w:tblW')
    tblW.set(qn('w:w'), '3750')  # 3750/5000 = 75%
    tblW.set(qn('w:type'), 'pct')
    tblPr.append(tblW)


def _add_html_altchunk(doc, html_str, base_url=''):
    """HTML을 Word altChunk로 삽입 (이미지 base64 임베드 → 포맷 완전 보존).
    Word가 파일을 열 때 HTML을 직접 렌더링하므로 붙여넣기와 동일한 결과."""
    soup = BeautifulSoup(html_str, 'html.parser')

    # 이미지 src → base64 data URI 변환 (네트워크 불필요)
    for img in soup.find_all('img', src=True):
        src = img.get('src', '')
        if src.startswith('data:'):
            continue
        if not src.startswith('http') and base_url:
            src = urljoin(base_url, src)
        if src.startswith('http'):
            try:
                r = requests.get(src, headers=HEADERS, timeout=8)
                if r.status_code == 200 and r.content:
                    ct = r.headers.get('content-type', 'image/jpeg').split(';')[0]
                    b64 = base64.b64encode(r.content).decode('ascii')
                    img['src'] = f'data:{ct};base64,{b64}'
                    continue
            except Exception:
                pass
        img.decompose()  # 로드 실패 이미지 제거

    full_html = (
        '<!DOCTYPE html><html><head>'
        '<meta charset="UTF-8">'
        '<style>'
        'body{font-family:"맑은 고딕",Malgun Gothic,sans-serif;font-size:10pt;margin:0;padding:0;}'
        'img{max-width:50%;height:auto;display:block;}'
        'table{border-collapse:collapse;}td,th{border:1px solid #ccc;padding:4px;}'
        '</style></head><body>'
        + str(soup)
        + '</body></html>'
    )

    html_bytes = full_html.encode('utf-8')
    chunk_id = f'afc{uuid.uuid4().hex[:8]}'

    html_part = Part(PackURI(f'/word/{chunk_id}.html'), 'text/html', html_bytes)
    rel_id = doc.part.relate_to(html_part, _AFCHUNK_REL)

    altchunk = OxmlElement('w:altChunk')
    altchunk.set(qn('r:id'), rel_id)

    # body.append()는 <w:sectPr> 뒤에 붙어 문서 맨 아래로 가므로,
    # sectPr 바로 앞에 삽입하여 현재 커서 위치를 유지
    body = doc.element.body
    sectPr = body.find(qn('w:sectPr'))
    if sectPr is not None:
        sectPr.addprevious(altchunk)
        # 앵커 단락: 이후 doc.add_paragraph()가 altChunk 앞이 아닌 뒤에 삽입되도록
        anchor = OxmlElement('w:p')
        sectPr.addprevious(anchor)
    else:
        body.append(altchunk)


def _add_cover_page(doc, date_str):
    """표지 페이지"""
    dt = datetime.strptime(date_str, '%Y-%m-%d')

    # ── 제목: 42pt / 진한파랑 / 볼드 / 좌측 정렬 ───────────────
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    title_p.paragraph_format.space_before = Pt(36)
    title_p.paragraph_format.space_after = Pt(0)
    r = title_p.add_run('일일 외부 동향')
    r.bold = True
    r.font.size = Pt(42)
    r.font.name = '맑은 고딕'
    r.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)

    # ── 목차: 12pt / 진한파랑
    # 첫 항목에 큰 space_before 를 주어 하단으로 밀고,
    # 이후 항목은 space_before=12pt 로 빈 줄 효과 — 별도 빈 단락 없음
    sections = [
        '보안 기사',
        '보안 권고문 및 동향',
        '보안 취약점',
        '공개된 신규 취약점 (ExploitDB)',
        '공개된 신규 취약점 (GitHub)',
    ]
    for idx, sec in enumerate(sections, 1):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.space_before = Pt(130) if idx == 1 else Pt(12)
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(f"{idx}. {sec}")
        r.font.size = Pt(12)
        r.font.name = '맑은 고딕'
        r.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)

    # ── 날짜: 연.월.일 형식 ─────────────────────────────────────
    date_p = doc.add_paragraph()
    date_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    date_p.paragraph_format.space_before = Pt(24)
    date_p.paragraph_format.space_after = Pt(0)
    dr = date_p.add_run(f"{dt.year}.{dt.month:02d}.{dt.day:02d}")
    dr.font.size = Pt(12)
    dr.font.name = '맑은 고딕'
    dr.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)

    doc.add_page_break()


# ============================================================
# DOCX 생성
# ============================================================

def _set_doc_default_font(doc, font_name='맑은 고딕'):
    """문서 전체 기본 폰트를 지정 글꼴로 설정"""
    style = doc.styles['Normal']
    style.font.name = font_name
    rPr = style.element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    for attr in ('w:ascii', 'w:hAnsi', 'w:eastAsia', 'w:cs'):
        rFonts.set(qn(attr), font_name)


def create_docx(data):
    doc = Document()
    _set_doc_default_font(doc)

    # --- 페이지 여백 설정 ---
    for section in doc.sections:
        section.top_margin = Cm(2)
    section.bottom_margin = Cm(2)
    section.left_margin = Cm(2.5)
    section.right_margin = Cm(2.5)

    # --- 표지 (오늘 날짜 기준) ---
    _add_cover_page(doc, datetime.now(KST).strftime('%Y-%m-%d'))

    # ================================================================
    # 1. 보안 뉴스
    # ================================================================
    _add_section_heading(doc, '1. 보안 기사', level=1)

    if data['boannews']:
        for i, item in enumerate(data['boannews'], 1):
            heading_p = doc.add_paragraph()
            run = heading_p.add_run(f"1-{i}. {item['title']} - 보안뉴스")
            run.bold = True
            run.font.size = Pt(14)
            run.font.color.rgb = RGBColor(0x00, 0x00, 0x00)

            if item.get('content_html'):
                _add_html_altchunk(doc,
                    _make_box_html(item['content_html'], item['url']),
                    'https://www.boannews.com')
            else:
                tbl = doc.add_table(rows=1, cols=1)
                tbl.style = 'Table Grid'
                cell = tbl.cell(0, 0)
                cell.paragraphs[0].add_run(item.get('content') or item['title']).font.size = Pt(12)
                url_p = cell.add_paragraph(f"원문 : {item['url']}")
                url_p.runs[0].font.size = Pt(12)
                url_p.runs[0].font.color.rgb = RGBColor(0x1A, 0x73, 0xE8)

            doc.add_paragraph()
    else:
        doc.add_paragraph('해당 기간 내 뉴스가 없습니다.')

    doc.add_paragraph()

    # ================================================================
    # 2. 보안 권고문
    # ================================================================
    _add_section_heading(doc, '2. 보안 권고문 및 동향', level=1)

    # KISA + CERT/CC 항목을 순서대로 번호 부여
    _SOURCE_LABEL = {
        'KISA 보호나라': 'KRCERT(보안권고문)',
        'CERT/CC':       'US-CERT',
    }
    all_advisories = (
        [dict(item, source='KISA 보호나라') for item in data['kisa']] +
        [dict(item, source='CERT/CC')       for item in data['certcc']]
    )

    if all_advisories:
        for i, item in enumerate(all_advisories, 1):
            heading_p = doc.add_paragraph()
            display_src = _SOURCE_LABEL.get(item['source'], item['source'])
            run = heading_p.add_run(f"2-{i}. {item['title']} - {display_src}")
            run.bold = True
            run.font.size = Pt(14)
            run.font.color.rgb = RGBColor(0x00, 0x00, 0x00)

            if item.get('content_html'):
                base_url = ('https://www.boho.or.kr'
                            if item.get('source') == 'KISA 보호나라'
                            else 'https://www.kb.cert.org')
                _add_html_altchunk(doc,
                    _make_box_html(item['content_html'], item['url']),
                    base_url)
            else:
                tbl = doc.add_table(rows=1, cols=1)
                tbl.style = 'Table Grid'
                cell = tbl.cell(0, 0)
                cell.paragraphs[0].add_run(item.get('content') or item['title']).font.size = Pt(12)
                url_p = cell.add_paragraph(f"원문 : {item['url']}")
                url_p.runs[0].font.size = Pt(12)
                url_p.runs[0].font.color.rgb = RGBColor(0x1A, 0x73, 0xE8)

            doc.add_paragraph()
    else:
        doc.add_paragraph('해당 날짜의 보안 권고문이 없습니다.')

    doc.add_paragraph()

    # ================================================================
    # 3. 취약점 정보 - FCTI
    # ================================================================
    _add_section_heading(doc, '3. 보안 취약점', level=1)

    if data['cve_data']:
        for i, item in enumerate(data['cve_data'], 1):
            heading_p = doc.add_paragraph()
            run = heading_p.add_run(f"3-{i}. {item['cve_id']} - FCTI")
            run.bold = True
            run.font.size = Pt(14)
            run.font.color.rgb = RGBColor(0x00, 0x00, 0x00)

            tbl = doc.add_table(rows=1, cols=1)
            tbl.style = 'Table Grid'
            _set_table_half_width(tbl)
            cell = tbl.cell(0, 0)

            def _add_fcti_field(cell, label, value, first=False):
                p = cell.paragraphs[0] if first else cell.add_paragraph()
                r = p.add_run(f"{label} : ")
                r.bold = True
                r.font.size = Pt(12)
                p.add_run(value).font.size = Pt(12)

            _add_fcti_field(cell, 'CVE',         item['cve_id'],              first=True)
            cell.add_paragraph()
            _add_fcti_field(cell, 'Description', item.get('description', ''))
            cell.add_paragraph()
            _add_fcti_field(cell, 'Date',        item.get('date', '-'))

            doc.add_paragraph()
    else:
        doc.add_paragraph('입력된 CVE 데이터가 없습니다.')

    doc.add_paragraph()

    # ================================================================
    # 4. Exploit-DB
    # ================================================================
    _add_section_heading(doc, '4. 공개된 신규 취약점 (ExploitDB)', level=1)

    if data['exploitdb']:
        for i, item in enumerate(data['exploitdb'], 1):
            # 항목 제목 행: 4-N. 설명 - Exploit-DB
            heading_p = doc.add_paragraph()
            run = heading_p.add_run(f"4-{i}. {item['description']} - ExploitDB")
            run.bold = True
            run.font.size = Pt(14)
            run.font.color.rgb = RGBColor(0x00, 0x00, 0x00)

            # 1×1 표: CVE ID / Description / Date / URL
            tbl = doc.add_table(rows=1, cols=1)
            tbl.style = 'Table Grid'
            _set_table_half_width(tbl)
            cell = tbl.cell(0, 0)

            cve_str = ', '.join(item.get('cves', [])) or '-'

            def _add_field(cell, label, value, first=False):
                p = cell.paragraphs[0] if first else cell.add_paragraph()
                lr = p.add_run(f"{label} : ")
                lr.bold = True
                lr.font.size = Pt(12)
                p.add_run(value).font.size = Pt(12)

            _add_field(cell, 'CVE ID',      cve_str,              first=True)
            cell.add_paragraph()
            _add_field(cell, 'Description', item['description'])
            cell.add_paragraph()
            _add_field(cell, 'Date',        item.get('date', '-'))
            cell.add_paragraph()

            url_p = cell.add_paragraph()
            url_p.add_run('URL : ').bold = True
            url_run = url_p.add_run(item['url'])
            url_run.font.size = Pt(12)
            url_run.font.color.rgb = RGBColor(0x1A, 0x73, 0xE8)

            doc.add_paragraph()
    else:
        doc.add_paragraph('해당 날짜의 Exploit-DB 항목이 없습니다.')

    doc.add_paragraph()

    # ================================================================
    # 5. GitHub PoC
    # ================================================================
    _add_section_heading(doc, '5. 공개된 신규 취약점 (GitHub)', level=1)

    if data['github_pocs']:
        for i, item in enumerate(data['github_pocs'], 1):
            readme_title = _fetch_readme_title(item['url'])
            if not readme_title:
                parts = item['url'].rstrip('/').split('/')
                readme_title = '/'.join(parts[-2:]) if len(parts) >= 5 else item['cve']
            heading_p = doc.add_paragraph()
            run = heading_p.add_run(f"5-{i}. {readme_title} - GitHub")
            run.bold = True
            run.font.size = Pt(14)
            run.font.color.rgb = RGBColor(0x00, 0x00, 0x00)

            tbl = doc.add_table(rows=1, cols=1)
            tbl.style = 'Table Grid'
            _set_table_half_width(tbl)
            cell = tbl.cell(0, 0)

            def _add_poc_field(cell, label, value, first=False):
                p = cell.paragraphs[0] if first else cell.add_paragraph()
                r = p.add_run(f"{label} : ")
                r.bold = True
                r.font.size = Pt(12)
                p.add_run(value).font.size = Pt(12)

            _add_poc_field(cell, 'CVE ID',      item['cve'],  first=True)
            cell.add_paragraph()
            _add_poc_field(cell, 'Date',         '')
            cell.add_paragraph()
            _add_poc_field(cell, 'Description',  '')
            cell.add_paragraph()
            _add_poc_field(cell, 'PoC',          item['url'])

            doc.add_paragraph()
    else:
        doc.add_paragraph('조건에 맞는 PoC가 없습니다.')

    # --- 저장 ---
    base_dir = os.path.dirname(os.path.abspath(__file__))
    docx_dir = os.path.join(base_dir, 'docx')
    os.makedirs(docx_dir, exist_ok=True)

    date_str = datetime.now(KST).strftime('%Y%m%d')   # 오늘 날짜
    base_name = f"일일 외부 동향_{date_str}"
    filepath = os.path.join(docx_dir, f"{base_name}.docx")
    if os.path.exists(filepath):
        n = 1
        while os.path.exists(os.path.join(docx_dir, f"{base_name}_{n}.docx")):
            n += 1
        filepath = os.path.join(docx_dir, f"{base_name}_{n}.docx")

    doc.save(filepath)
    print(f"  → 저장: {filepath}")
    return filepath


# ============================================================
# 이메일 본문 (텍스트) 생성
# ============================================================

def create_email_text(data):
    """복사·붙여넣기용 순수 텍스트 이메일 본문 생성"""
    today = datetime.now(KST)
    date_str = f"{today.month}월 {today.day}일"

    lines = [
        "안녕하세요 보안관제 OOO입니다.",
        "",
        f"{date_str} 일일 외부 동향 보내드립니다.",
        "",
        "1. 보안뉴스",
    ]
    if data.get('boannews'):
        for i, item in enumerate(data['boannews'], 1):
            lines.append(f"  1-{i}. {item['title']}")
    else:
        lines.append("  해당 기간 내 뉴스가 없습니다.")

    lines.append("")
    lines.append("2. 보안 권고문")
    idx = 1
    for item in data.get('kisa', []):
        lines.append(f"  2-{idx}. {item['title']} - KRCERT(보안권고문)")
        lines.append("")
        idx += 1
    for item in data.get('certcc', []):
        lines.append(f"  2-{idx}. {item['title']} - US-CERT")
        lines.append("")
        idx += 1
    if idx == 1:
        lines.append("  해당 날짜의 새로운 취약점 정보가 없습니다.")

    lines.append("")
    lines.append("3. 취약점 정보")
    if data.get('cve_data'):
        for i, item in enumerate(data['cve_data'], 1):
            lines.append(f"  3-{i}. {item['cve_id']} - FCTI")
            lines.append(f"    - CVE ID : {item['cve_id']}")
            lines.append(f"    - 확인 내용 : ")
            lines.append("")
    else:
        lines.append("  입력된 CVE 데이터가 없습니다.")

    lines.append("")
    lines.append("4. 공개된 신규 취약점 (ExploitDB)")
    if data.get('exploitdb'):
        for i, item in enumerate(data['exploitdb'], 1):
            cve_str = ', '.join(item.get('cves', [])) or '-'
            lines.append(f"  4-{i}. {item['description']} - ExploitDB")
            lines.append(f"    - CVE ID : {cve_str}")
            lines.append(f"    - 확인 내용 : ")
            lines.append("")
    else:
        lines.append("  해당 날짜의 항목이 없습니다.")

    lines.append("")
    lines.append("5. 공개된 신규 취약점 (GitHub)")
    if data.get('github_pocs'):
        for i, item in enumerate(data['github_pocs'], 1):
            readme_title = _fetch_readme_title(item['url'])
            if not readme_title:
                parts = item['url'].rstrip('/').split('/')
                readme_title = '/'.join(parts[-2:]) if len(parts) >= 5 else item['cve']
            lines.append(f"  5-{i}. {readme_title} - GitHub")
            lines.append(f"    - CVE ID : {item['cve']}")
            lines.append(f"    - 확인 내용 : ")
            lines.append(f"    - URL : {item['url']}")
            lines.append("")
    else:
        lines.append("  조건에 맞는 PoC가 없습니다.")

    lines.append("")
    lines.append("감사합니다.")

    return "\n".join(lines)


# ============================================================
# 이메일 양식 (HTML) 생성
# ============================================================

def create_email_template(data):
    """HTML 이메일 양식 생성"""

    def _rows_boannews():
        if not data['boannews']:
            return '<tr><td colspan="3">해당 기간 내 뉴스가 없습니다.</td></tr>'
        rows = ''
        for i, item in enumerate(data['boannews'], 1):
            rows += (
                f'<tr>'
                f'<td style="text-align:center;">{i}</td>'
                f'<td><a href="{item["url"]}">{item["title"]}</a></td>'
                f'<td style="text-align:center;white-space:nowrap;">{item["time"]}</td>'
                f'</tr>'
            )
        return rows

    def _li_kisa():
        if not data['kisa']:
            return '<li>해당 날짜의 새로운 취약점 정보가 없습니다.</li>'
        return ''.join(
            f'<li><a href="{it["url"]}">{it["title"]}</a></li>'
            for it in data['kisa']
        )

    def _li_certcc():
        if not data['certcc']:
            return '<li>해당 날짜의 새로운 취약점 정보가 없습니다.</li>'
        rows = ''
        for it in data['certcc']:
            cve_str = (', '.join(it.get('cves', []))) or '-'
            rows += (
                f'<li><a href="{it["url"]}">{it["title"]}</a>'
                f'&nbsp;<span style="color:#555;font-size:11px;">[{cve_str}]</span></li>'
            )
        return rows

    def _rows_cve():
        if not data['cve_data']:
            return '<tr><td colspan="3">입력된 CVE 데이터가 없습니다.</td></tr>'
        rows = ''
        for i, it in enumerate(data['cve_data'], 1):
            desc = it['description'].replace('\n', '<br>')
            rows += (
                f'<tr>'
                f'<td style="text-align:center;white-space:nowrap;"><b>{it["cve_id"]}</b></td>'
                f'<td style="text-align:center;white-space:nowrap;">{it["date"]}</td>'
                f'<td style="font-size:12px;">{desc}</td>'
                f'</tr>'
            )
        return rows

    def _rows_exploitdb():
        if not data['exploitdb']:
            return '<tr><td colspan="4">해당 날짜의 항목이 없습니다.</td></tr>'
        rows = ''
        for i, it in enumerate(data['exploitdb'], 1):
            cve_str = ', '.join(it.get('cves', [])) or '-'
            rows += (
                f'<tr>'
                f'<td style="text-align:center;">{i}</td>'
                f'<td><a href="{it["url"]}">{it["description"]}</a></td>'
                f'<td style="text-align:center;">{cve_str}</td>'
                f'<td style="text-align:center;">{it.get("platform","") or "-"}</td>'
                f'</tr>'
            )
        return rows

    def _rows_poc():
        if not data['github_pocs']:
            return '<tr><td colspan="3">조건에 맞는 PoC가 없습니다.</td></tr>'
        rows = ''
        for i, it in enumerate(data['github_pocs'], 1):
            rows += (
                f'<tr>'
                f'<td style="text-align:center;"><b>{it["cve"]}</b></td>'
                f'<td>{it["content"]}</td>'
                f'<td style="text-align:center;"><a href="{it["url"]}">GitHub</a></td>'
                f'</tr>'
            )
        return rows

    gen_time = datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')

    html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>보안 외부 동향 {data['date']}</title>
<style>
  body {{
    font-family: 'Malgun Gothic','맑은 고딕',Arial,sans-serif;
    font-size:13px; color:#222; background:#f4f6f8;
    margin:0; padding:20px;
  }}
  .wrap {{ max-width:900px; margin:auto; background:#fff;
           border:1px solid #dde; border-radius:6px; overflow:hidden; }}
  .header {{
    background:linear-gradient(135deg,#1a3a5c,#2e6da4);
    color:#fff; padding:20px 28px;
  }}
  .header h1 {{ margin:0 0 4px; font-size:20px; }}
  .header p  {{ margin:0; font-size:12px; opacity:.8; }}
  .body {{ padding:20px 28px; }}
  h2 {{
    background:#1f3864; color:#fff;
    padding:7px 14px; margin:24px 0 10px;
    font-size:14px; border-radius:3px;
  }}
  h3 {{
    background:#2e6da4; color:#fff;
    padding:5px 12px; margin:14px 0 8px;
    font-size:13px; border-radius:3px;
  }}
  table {{
    border-collapse:collapse; width:100%; margin-bottom:6px;
  }}
  th {{
    background:#1f3864; color:#fff;
    padding:7px 10px; text-align:center;
    font-size:12px; border:1px solid #bbb;
  }}
  td {{
    padding:6px 10px; border:1px solid #ddd;
    vertical-align:top; font-size:12px;
  }}
  tr:nth-child(even) td {{ background:#f8f9ff; }}
  a {{ color:#1a73e8; text-decoration:none; }}
  a:hover {{ text-decoration:underline; }}
  ul {{ margin:4px 0; padding-left:22px; }}
  li {{ margin-bottom:4px; }}
  .footer {{
    margin-top:24px; padding-top:10px;
    border-top:1px solid #ddd;
    font-size:11px; color:#999; text-align:center;
  }}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h1>보안 외부 동향</h1>
    <p>기준일: {data['date']} &nbsp;|&nbsp; 생성시각: {gen_time} KST</p>
  </div>
  <div class="body">

    <!-- 1. 보안 뉴스 -->
    <h2>1. 보안 뉴스 &nbsp;<small style="font-weight:normal;font-size:12px;">(보안뉴스, 24시간 이내)</small></h2>
    <table>
      <thead>
        <tr><th style="width:40px;">No</th><th>제목</th><th style="width:130px;">발행시간</th></tr>
      </thead>
      <tbody>{_rows_boannews()}</tbody>
    </table>

    <!-- 2. 취약점 정보 -->
    <h2>2. 취약점 정보 &nbsp;<small style="font-weight:normal;font-size:12px;">({data['date']} 기준)</small></h2>
    <h3>2-1. KISA 보호나라</h3>
    <ul>{_li_kisa()}</ul>
    <h3>2-2. CERT/CC</h3>
    <ul>{_li_certcc()}</ul>

    <!-- 3. CVE 상세 정보 -->
    <h2>3. CVE 상세 정보 &nbsp;<small style="font-weight:normal;font-size:12px;">(입력 데이터)</small></h2>
    <table>
      <thead>
        <tr>
          <th style="width:140px;">CVE ID</th>
          <th style="width:100px;">날짜</th>
          <th>설명 (영문 원문)</th>
        </tr>
      </thead>
      <tbody>{_rows_cve()}</tbody>
    </table>

    <!-- 4. Exploit-DB -->
    <h2>4. Exploit-DB &nbsp;<small style="font-weight:normal;font-size:12px;">({data['date']} 기준, PoC 소스 제외)</small></h2>
    <table>
      <thead>
        <tr>
          <th style="width:40px;">No</th>
          <th>설명</th>
          <th style="width:140px;">CVE</th>
          <th style="width:90px;">플랫폼</th>
        </tr>
      </thead>
      <tbody>{_rows_exploitdb()}</tbody>
    </table>

    <!-- 5. GitHub PoC -->
    <h2>5. GitHub PoC &nbsp;<small style="font-weight:normal;font-size:12px;">(CVSS 7.5+ / nomi-sec/PoC-in-GitHub)</small></h2>
    <table>
      <thead>
        <tr>
          <th style="width:140px;">CVE ID</th>
          <th>확인 내용</th>
          <th style="width:80px;">링크</th>
        </tr>
      </thead>
      <tbody>{_rows_poc()}</tbody>
    </table>

    <div class="footer">
      본 메일은 자동 생성된 보안 외부 동향 보고서입니다.
    </div>
  </div>
</div>
</body>
</html>"""

    now_str = datetime.now(KST).strftime('%Y%m%d_%H%M')
    filename = f"보안외부동향_메일_{now_str}.html"
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"  → 저장: {filepath}")
    return filepath


# ============================================================
# 메인
# ============================================================

def main():
    now, yesterday = get_dates()

    print("=" * 60)
    print("  보안 외부 동향 보고서 자동 생성기")
    print("=" * 60)
    print(f"  실행 시각 : {now.strftime('%Y-%m-%d %H:%M:%S')} KST")
    print(f"  기준 날짜 : {yesterday.strftime('%Y-%m-%d')} (전일)")
    print("=" * 60)

    # 1. 보안뉴스
    print("\n[1/5] 보안뉴스 크롤링 (24시간 이내)...")
    boannews = crawl_boannews()
    print(f"  → {len(boannews)}건 수집")

    # 2. 취약점 정보
    print("\n[2/5] 취약점 정보 크롤링...")
    kisa = crawl_kisa(yesterday)
    certcc = crawl_certcc(yesterday)
    print(f"  → KISA: {len(kisa)}건 / CERT/CC: {len(certcc)}건")

    # 3. CVE 입력 (사용자 상호작용)
    print("\n[3/5] CVE 데이터 입력")
    cve_data = parse_cve_input()
    print(f"  → {len(cve_data)}건 파싱 완료")

    # 4. Exploit-DB
    print("\n[4/5] Exploit-DB 크롤링...")
    exploitdb = crawl_exploitdb(yesterday)
    print(f"  → {len(exploitdb)}건 수집")

    # 5. git.py 실행
    print("\n[5/5] GitHub PoC 분석 (git.py 실행)...")
    github_pocs = run_git_py()
    print(f"  → {len(github_pocs)}건 수집")

    # 데이터 취합
    data = {
        'date': yesterday.strftime('%Y-%m-%d'),
        'boannews': boannews,
        'kisa': kisa,
        'certcc': certcc,
        'cve_data': cve_data,
        'exploitdb': exploitdb,
        'github_pocs': github_pocs
    }

    # 출력물 생성
    print("\n[*] DOCX 생성 중...")
    docx_path = create_docx(data)

    print("[*] 이메일 양식 생성 중...")
    email_path = create_email_template(data)

    print("\n" + "=" * 60)
    print("  완료!")
    print(f"  DOCX  : {docx_path}")
    print(f"  Email : {email_path}")
    print("=" * 60)


if __name__ == '__main__':
    main()

import requests
import urllib3
import ssl

# SSL 검증 완전 비활성화 (사내 보안장비 복호화 대응)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
try:
    ssl._create_default_https_context = ssl._create_unverified_context
except AttributeError:
    pass

_session = requests.Session()
_session.verify = False
requests.get = _session.get

import re
import json
import base64
from datetime import datetime, timedelta, timezone
import pytz
from dateutil import parser as dateutil_parser
from concurrent.futures import ThreadPoolExecutor, as_completed

# --- 설정 및 상수 ---
repo_owner = 'nomi-sec'
repo_name = 'PoC-in-GitHub'
commits_url = f'https://api.github.com/repos/{repo_owner}/{repo_name}/commits'
github_token = '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'

headers = {
    'Accept': 'application/vnd.github.v3+json',
    'Authorization': f'Bearer {github_token}',
}

local_timezone = pytz.timezone('Asia/Seoul')

# 의미 없는 파일 (정확한 파일명 소문자 매칭)
NON_MEANINGFUL_FILES = {
    'readme.md', 'readme.rst', 'readme.txt',
    '.gitignore', '.gitattributes', '.gitmodules',
    'license', 'licence', 'license.md', 'license.txt',
    'contributing.md', 'code_of_conduct.md', 'security.md',
    'changelog.md', 'changes.md', 'history.md', 'todo.md', 'authors.md',
    '.editorconfig', '.prettierrc', '.eslintrc', '.babelrc',
    '.travis.yml', 'appveyor.yml', '.gitlab-ci.yml', 'circle.yml',
    'requirements.txt', 'requirements-dev.txt', 'requirements-test.txt',
    'setup.py', 'setup.cfg', 'pyproject.toml', 'pipfile', 'pipfile.lock',
    'package.json', 'package-lock.json', 'yarn.lock', 'bun.lockb',
    'gemfile', 'gemfile.lock', 'composer.json', 'composer.lock',
    'cargo.toml', 'cargo.lock', 'go.mod', 'go.sum',
    'pom.xml', 'build.gradle', 'build.xml', 'makefile', 'cmakelists.txt',
    'dockerfile', 'docker-compose.yml', 'docker-compose.yaml',
}

# 유의미한 PoC 소스코드로 인정하는 확장자
MEANINGFUL_EXTENSIONS = {
    '.py', '.c', '.cpp', '.cc', '.cxx', '.h', '.hpp',
    '.java', '.js', '.ts', '.jsx', '.tsx',
    '.go', '.rb', '.php', '.pl', '.pm',
    '.sh', '.bash', '.zsh', '.fish',
    '.ps1', '.psm1', '.psd1', '.bat', '.cmd',
    '.cs', '.rs', '.swift', '.kt', '.scala',
    '.lua', '.r', '.m', '.asm', '.s', '.nasm',
    '.ex', '.exs', '.erl', '.nim', '.zig',
    '.vb', '.groovy', '.dart',
}

MAX_WORKERS = 10


def get_commits_from_previous_day():
    now = datetime.now(local_timezone)
    prev = now - timedelta(days=1)

    response = requests.get(commits_url, headers=headers)
    if response.status_code != 200:
        print(f"[!] 커밋 목록 가져오기 실패: {response.status_code}")
        return []

    data = response.json()
    filtered = []
    for c in data:
        msg = c.get('commit', {}).get('message', '')
        m = re.search(r'(\d{4}/\d{2}/\d{2})', msg)
        if m:
            try:
                dt = datetime.strptime(m.group(1), '%Y/%m/%d')
                if dt.date() == prev.date():
                    filtered.append(c)
            except ValueError:
                continue
    return filtered


def extract_repo_data_recursively(obj):
    results = []
    if isinstance(obj, dict):
        pa = obj.get('pushed_at')
        hu = obj.get('html_url')
        owner_login = obj.get('owner', {}).get('login')
        r_name = obj.get('name')
        if pa and hu and owner_login and r_name:
            results.append({'pushed_at': pa, 'html_url': hu, 'owner': owner_login, 'name': r_name})
        for v in obj.values():
            results.extend(extract_repo_data_recursively(v))
    elif isinstance(obj, list):
        for it in obj:
            results.extend(extract_repo_data_recursively(it))
    return results


def extract_repo_data_from_file_content(file_url):
    resp = requests.get(file_url, headers=headers)
    if resp.status_code != 200:
        return []
    j = resp.json()
    content = j.get('content')
    if not content:
        return []
    try:
        dec = base64.b64decode(content).decode('utf-8')
        jd = json.loads(dec)
    except Exception:
        return []
    return extract_repo_data_recursively(jd)


def is_within_last_24_hours(pushed_at):
    try:
        pushed_time = dateutil_parser.parse(pushed_at)
    except Exception:
        return False
    now = datetime.now(timezone.utc)
    if pushed_time.tzinfo is None:
        pushed_time = pushed_time.replace(tzinfo=timezone.utc)
    return (now - pushed_time) <= timedelta(hours=24)


def get_base_score_from_nvd(cve_id):
    url = f'https://olbat.github.io/nvdcve/{cve_id}.json'
    r = requests.get(url)
    if r.status_code != 200:
        return None
    match = re.search(r'[Bb]ase[Ss]core":?\s*([0-9]+\.[0-9]+)', r.text)
    if match:
        score = float(match.group(1))
        return score if score >= 7.5 else None
    return None


def extract_cve_id_from_filename(fn):
    m = re.search(r'CVE-\d{4}-\d+', fn)
    return m.group(0) if m else None


def _is_meaningful_poc_file(filepath):
    """파일 경로가 유의미한 PoC 소스코드인지 확인"""
    basename = filepath.lower().split('/')[-1]
    if basename in NON_MEANINGFUL_FILES:
        return False
    ext = '.' + basename.rsplit('.', 1)[-1] if '.' in basename else ''
    return ext in MEANINGFUL_EXTENSIONS


def is_poc_only_ignored_files_updated(owner, r_name):
    """최신 커밋에 유의미한 PoC 소스코드 파일이 없으면 True(제외) 반환"""
    # main 브랜치 우선, 실패 시 기본 브랜치 재시도
    for branch in ('main', None):
        params = {'per_page': 1}
        if branch:
            params['sha'] = branch
        resp = requests.get(
            f'https://api.github.com/repos/{owner}/{r_name}/commits',
            headers=headers, params=params
        )
        if resp.status_code == 200 and resp.json():
            break
    else:
        return True

    latest_sha = resp.json()[0]['sha']
    detail_resp = requests.get(
        f'https://api.github.com/repos/{owner}/{r_name}/commits/{latest_sha}',
        headers=headers
    )
    if detail_resp.status_code != 200:
        return True

    files = detail_resp.json().get('files', [])
    if not files:
        return True  # 변경 파일 없음 → 제외

    # 유의미한 소스코드 파일이 하나라도 있으면 유효 (False = 제외 안 함)
    for f in files:
        if _is_meaningful_poc_file(f.get('filename', '')):
            return False

    return True  # 코드 파일 없음 → 제외


def _fetch_commit_files(sha):
    url = f'https://api.github.com/repos/{repo_owner}/{repo_name}/commits/{sha}'
    cr = requests.get(url, headers=headers)
    if cr.status_code != 200:
        return sha, []
    return sha, cr.json().get('files', [])


def _process_cve(cve, file_url, prefixes):
    """NVD 점수 확인 후 24h 이내 유효 레포 엔트리 반환"""
    score = get_base_score_from_nvd(cve)
    if not score:
        return None

    repo_entries = extract_repo_data_from_file_content(file_url)
    valid = [e for e in repo_entries
             if e['pushed_at'][:10] in prefixes and is_within_last_24_hours(e['pushed_at'])]

    return (cve, score, valid) if valid else None


def _check_poc(cve, entry):
    if is_poc_only_ignored_files_updated(entry['owner'], entry['name']):
        return None
    return (cve, entry['html_url'])


def process_json_files():
    commits = get_commits_from_previous_day()
    if not commits:
        print("[*] 전일 분석 대상 커밋이 없습니다.")
        return

    now_utc = datetime.now(timezone.utc)
    prefixes = [
        now_utc.strftime('%Y-%m-%d'),
        (now_utc - timedelta(days=1)).strftime('%Y-%m-%d'),
        (now_utc - timedelta(days=2)).strftime('%Y-%m-%d')
    ]

    print("[*] 분석 시작... (병렬 처리 모드)")

    # 1단계: 모든 커밋 파일 목록 병렬 수집
    sha_list = [c['sha'] for c in commits]
    commit_files = {}
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        for sha, files in ex.map(_fetch_commit_files, sha_list):
            commit_files[sha] = files

    # 2단계: JSON 파일 후보 수집 (CVE 중복 제거)
    cve_tasks = {}  # cve -> file_url
    for sha in sha_list:
        files = commit_files.get(sha, [])
        for f in files:
            fn = f.get('filename', '')
            if not fn.endswith('.json'):
                continue
            cve = extract_cve_id_from_filename(fn)
            if not cve or cve in cve_tasks:
                continue
            cve_tasks[cve] = f'https://api.github.com/repos/{repo_owner}/{repo_name}/contents/{fn}'

    if not cve_tasks:
        print("\n" + "="*50)
        print("[*] 분석 완료: 조건에 맞는 결과가 없습니다.")
        print("="*50)
        return

    # 3단계: NVD 점수 확인 + 레포 엔트리 병렬 처리
    candidates = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futures = {ex.submit(_process_cve, cve, url, prefixes): cve
                   for cve, url in cve_tasks.items()}
        for future in as_completed(futures):
            result = future.result()
            if result:
                cve, score, valid_entries = result
                print(f" [+] 분석 중: {cve} (Score: {score})")
                candidates.append((cve, valid_entries))

    # 4단계: PoC 유효성 병렬 확인 (README 단독 업데이트 필터)
    out = []
    confirmed_cves = set()

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futures = {}
        for cve, entries in candidates:
            for entry in entries:
                f = ex.submit(_check_poc, cve, entry)
                futures[f] = cve

        for future in as_completed(futures):
            result = future.result()
            if result:
                cve, url = result
                if cve not in confirmed_cves:
                    confirmed_cves.add(cve)
                    out.append({'cve': cve, 'url': url})

    # 최종 결과 출력
    out.sort(key=lambda x: x['cve'])
    print("\n" + "="*50)
    if out:
        print(f"[*] 분석 완료: 총 {len(out)}건의 유효한 PoC 발견\n")
        for idx, info in enumerate(out, 1):
            print(f"5-{idx}. - Github")
            print(f" - CVE ID : {info['cve']}")
            print(f" - 확인내용 : 유의미한 코드 업데이트 감지됨")
            print(f" - Link : {info['url']}\n")
    else:
        print("[*] 분석 완료: 조건에 맞는 결과가 없습니다.")
    print("="*50)


if __name__ == '__main__':
    process_json_files()
